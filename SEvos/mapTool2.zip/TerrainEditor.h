//-----------------------------------------------------------------------------//
// 2009-08-07  programer: jaejung ��(���բ�)��
// 
//-----------------------------------------------------------------------------//

#if !defined(__MAP_EDITOR_H__)
#define __MAP_EDITOR_H__


#include "global.h"
#include "terrain.h"

class CTerrainEditor : public CTerrain
{
public:
	CTerrainEditor();
	virtual ~CTerrainEditor();

protected:
	typedef struct _tagSHoverObj
	{
		_tagSHoverObj() {}
		_tagSHoverObj( int id, OBJ_TYPE e, char *c, CModel* p ): nId(id), eOType(e), pModel(p) 
		{ 
			if( c ) strcpy_s( szObjName, sizeof(szObjName), c );
		}

		int nId;
		OBJ_TYPE eOType;
		char szObjName[ 64];
		CModel* pModel;
	} SHoverObj;

	typedef std::list<SHoverObj>::iterator HoverItor;
	std::list<SHoverObj> m_HoverList;
	std::list<SHoverObj> m_CaptureList;

	// Ÿ��
	BOOL m_bDrawChunkEdge; // TRUE
	CMesh m_TerrainEditCursor;

public:
	virtual void Render();
	virtual void Update( int nElapsTick );
	BOOL Create( SCrTerrain *pCrInfo );
	BOOL Save( char *szFileName );

	// hover
	void SetHover( OBJ_TYPE eOType, char *szObjName );
	void HoverCancel();
	BOOL CaptureToHover( LPPOINT lpPos );
	int Capture( LPRECT lpRect );
	void MoveHoverObj( Vector2 vPos );
	BOOL LocateModel( Vector2 vPos );
	void UpdateObjPos();

	// Terrain
	void SetHeight( Vector2 vPos, CURSOR_TYPE eType, float fSize, float fHeightOffset );

	// Brush
	void setVisibleBrush(BOOL visible);
	void MoveBrush( SBrushInfo *pbrush, Vector2 screenpos );
	BOOL DrawBrush( SBrushInfo *pbrush, Vector2 screenpos );

	// Chunk
	void SetFocusChunk( CChunk *pchunk );
	CChunk* GetChunkFrom2D( Vector2 screenpos, float *pu=NULL, float *pv=NULL );
	CChunk* GetChunkFrom3D( Vector3 pos, float *pu=NULL, float *pv=NULL );
	CChunk* GetChunkFromAxis( int x, int y );
	BOOL SetChunk( int x, int y, CChunk *pchunk );
	void OptimizeChunk();
	void ApplyHeightToChunk( CMesh *pheightrange );
	void SetDrawChunkEdgeOption( BOOL chunkdraw );

	// Layer
	BOOL AddLayer( CChunk *pchunk );
	BOOL DeleteLayer( CChunk *pchunk, int layeridx );
	BOOL MergeLayer( CChunk *pchunk, int layeridx_from, int layeridx_to );
	BOOL MoveLayer( CChunk *pchunk, int layeridx_from, int layeridx_to );
	BOOL InsertLayer( CChunk *pchunk, int insert_layeridx, CChunk::SLayer *player );

protected:
	void SetHeightMapEntry( int nRow, int nCol, float fHeight );
	void Brush( float u, float v, SBrushInfo *pbrush, IDirect3DTexture9 *palpha );
	CChunk::SLayer* GetTopEditLayer( CChunk *pchunk, SBrushInfo *pbrush );
	void RenderChunkEdge();
	void RenderHeightRange();
//	void BrushInChunk( int chunk_x, int chunk_y, float brush_u, float brush_v );

	void getMapVertex( Vector2 vPos, float fCircleSize, CMesh *pMapMesh );
	BOOL isInDrawBrush(CChunk *pchunk, float u, float v, SBrushInfo *pbrush);

};

#endif // __MAP_EDITOR_H__
