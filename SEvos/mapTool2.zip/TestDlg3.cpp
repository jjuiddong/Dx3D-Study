// TestDlg3.cpp : implementation file
//

#include "stdafx.h"
#include "maptool2.h"
#include "TestDlg3.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestDlg3 dialog


CTestDlg3::CTestDlg3(CWnd* pParent /*=NULL*/)
	: CDialog(CTestDlg3::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestDlg3)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTestDlg3::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestDlg3)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTestDlg3, CDialog)
	//{{AFX_MSG_MAP(CTestDlg3)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestDlg3 message handlers
