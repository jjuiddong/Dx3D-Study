// ModelPanel.cpp : implementation file
//

#include "stdafx.h"
#include "MapTool2.h"
#include "ModelPannel.h"
//#include "mapview.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CModelPanel dialog


CModelPanel::CModelPanel(CWnd* pParent /*=NULL*/)
	: CDialog(CModelPanel::IDD, pParent)
{
	//{{AFX_DATA_INIT(CModelPanel)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CModelPanel::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CModelPanel)
	DDX_Control(pDX, IDC_TREE_FILE, m_FileTree);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CModelPanel, CDialog)
	//{{AFX_MSG_MAP(CModelPanel)
	ON_BN_CLICKED(IDC_BUTTON_REFLESH, OnButtonReflesh)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CModelPanel message handlers

BOOL CModelPanel::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_FileTree.Init();
	LoadTable();

	return TRUE;
}


void CModelPanel::OnButtonReflesh() 
{
	m_FileTree.DeleteAllItems();
	LoadTable();
}

void CModelPanel::LoadTable()
{
//	m_FileTree.OpenModelTable( (char*)g_szModelTable );
//	SD_CTableMgr::LoadModelTable( (char*)g_szModelTable );

}

void CModelPanel::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	if( bShow ) 
	{
//		g_eEditMode = EM_MODEL;
//		g_pMapView->ChangedEditMode( g_eEditMode );
	}
}
