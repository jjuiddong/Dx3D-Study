//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MapTool2.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MAPTOOL2_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDD_DLG_MODEL                   129
#define IDD_DLG_TERRAIN                 130
#define IDD_DLG_CREATETERRAIN           131
#define IDD_DIALOG1                     140
#define IDD_DIALOG__                    141
#define IDB_BITMAP_FILETREE             143
#define IDD_DLG_TILE                    145
#define IDC_TAB_PANNEL                  1003
#define IDC_BUTTON_OPEN                 1004
#define IDC_BUTTON1                     1004
#define IDC_BUTTON_REFRESH              1004
#define IDC_BUTTON_SAVE                 1005
#define IDC_BUTTON_REFLESH              1005
#define IDC_STATIC_TILE_DIRPATH         1005
#define IDC_BUTTON_CREATE               1006
#define IDC_LIST_TILE                   1006
#define IDC_BUTTON_OPTION               1007
#define IDC_TREE_FILE                   1007
#define IDC_CHECK_FOG                   1008
#define IDC_CHECK_EDIT                  1008
#define IDC_SLIDER_BRUSHCENTER          1008
#define IDC_SLIDER_BRUSHSPEED           1009
#define IDC_CHECK_VERTEX                1012
#define IDC_CHECK_UPDOWN                1012
#define IDC_BUTTON_DELETELAYER          1012
#define IDC_STATIC_BRUSHSIZE            1013
#define IDC_CHECK_CHUNKEDGE             1013
#define IDC_SPIN_WIDTH                  1014
#define IDC_CHECK_TEXTURE               1014
#define IDC_STATIC_BRUSHCENTER          1014
#define IDC_SPIN_HEIGHT                 1015
#define IDC_STATIC_BRUSHSPEED           1015
#define IDC_SPIN_MPV                    1016
#define IDC_STATIC_MAXLAYERCOUNT        1016
#define IDC_STATIC_CHUNKPOS             1017
#define IDC_COMBO_WIDTH                 1018
#define IDC_CHECK_TILEEDIT              1018
#define IDC_COMBO_HEIGHT                1019
#define IDC_EDIT_EDGE_ALPHA             1019
#define IDC_COMBO_MPV                   1020
#define IDC_SCROLLBAR_EDGE_ALPHA        1020
#define IDC_EDIT_CENTER_ALPHA           1021
#define IDC_EDIT_TEXTURE                1022
#define IDC_SCROLLBAR_CENTER_ALPHA      1022
#define IDC_BUTTON_TEXTURE              1023
#define IDC_BUTTON_SHOWLAYER            1023
#define IDC_STATIC_VPR                  1024
#define IDC_BUTTON_EDITLAYER            1024
#define IDC_STATIC_VPC                  1025
#define IDC_BUTTON_HIDELAYER            1025
#define IDC_SLIDER_HOFFSET              1026
#define IDC_BUTTON_LOCKLAYER            1026
#define IDC_EDIT_HOFFSET                1027
#define IDC_LIST_LAYER                  1027
#define IDC_SPIN_HOFFSET                1028
#define IDC_CHECK_ERASEBRUSH            1028
#define IDC_SLIDER_BRUSHSIZE            1029
#define IDC_EDIT_BRUSHSIZE              1030
#define IDC_CHECK_MATCH_TEXTURE         1030
#define IDC_SPIN_BRUSH                  1031
#define IDC_STATIC_CURSORPOS            1032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        151
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
