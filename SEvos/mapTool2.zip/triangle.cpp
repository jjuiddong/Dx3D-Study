
#include "stdafx.h"
#include "math.h"

Triangle::Triangle()
{

}

Triangle::Triangle( const Vector3& vA, const Vector3& vB, const Vector3 &vC ):	
a(vA), b(vB), c( vC )
{
}

//----------------------------
// Init
//----------------------------
void Triangle::Init( const Vector3& vA, const Vector3& vB, const Vector3& vC )
{
	a = vA;
	b = vB;
	c = vC;
}

//----------------------------
// Triangle::Intersect
//----------------------------
BOOL Triangle::Intersect( const Vector3& vOrig, const Vector3& vDir,
	float*			pfT,		///< [OUT]
	float*			pfU,		///< [OUT]
	float*			pfV			///< [OUT]
	)
{
	static float u, v;

	// Find vectors for two edges sharing vert0

	static Vector3	vEdge1;
	static Vector3	vEdge2;

	vEdge1 = b - a;
	vEdge2 = c - a;

	// Begin calculating determinant - also used to calculate U parameter

	static Vector3	vP;
	vP = vDir.CrossProduct( vEdge2 );

	// If determinant is near zero, ray lies in plane of triangle

	float fDet = vEdge1.DotProduct( vP );
	if( fDet < 0.0001F )
	{
		return FALSE;
	} //if

	// Calculate distance from vert0 to ray origin

	static Vector3	vT;
	vT = vOrig - a;

	// Calculate U parameter and test bounds

	u = vT.DotProduct( vP );
	if( u < 0.0F || u > fDet )
	{
		return FALSE;
	} //if

	// Prepare to test V parameter

	static Vector3 vQ;
	vQ = vT.CrossProduct( vEdge1 );

	// Calculate V parameter and test bounds

	v = vDir.DotProduct( vQ );

	if( v < 0.0F || u + v > fDet )
	{
		return FALSE;
	} //if

	// Calculate t, scale parameters, ray intersects triangle

	float fInvDet = 1.0F / fDet;

	if( pfT )	*pfT = vEdge2.DotProduct( vQ ) * fInvDet;
	if( pfU )	*pfU = u * fInvDet;
	if( pfV )	*pfV = v * fInvDet;

	return TRUE;
}


//-----------------------------------------------------------------------------//
// vPos�� Triangle�� �Ÿ��� �����Ѵ�.
//-----------------------------------------------------------------------------//
float Triangle::Distance( const Vector3& vPos )
{
	Vector3 center;
	center.x = (a.x + b.x + c.x) / 3.f;
	center.y = (a.y + b.y + c.y) / 3.f;
	center.z = (a.z + b.z + c.z) / 3.f;
	return (vPos - center).Length();
}

