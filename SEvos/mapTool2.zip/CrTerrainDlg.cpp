// CCrTerrainDlg.cpp : implementation file
//

#include "stdafx.h"
#include "maptool2.h"
#include "CrTerrainDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCrTerrainDlg dialog


CCrTerrainDlg::CCrTerrainDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCrTerrainDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCrTerrainDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CCrTerrainDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCrTerrainDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCrTerrainDlg, CDialog)
	//{{AFX_MSG_MAP(CCrTerrainDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCrTerrainDlg message handlers

void CCrTerrainDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}

void CCrTerrainDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}
