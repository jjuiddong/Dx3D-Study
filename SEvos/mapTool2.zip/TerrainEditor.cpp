
#include "stdafx.h"
#include "terraineditor.h"
#include "linearmemloader.h"

#include "terrain.h"
#include "model.h"
#include "fileloader.h"

// Range Circle�� �׸������� Vertex,Index Buffer �޸�
const int MAX_RANGE_MEM = 512;

CTerrainEditor::CTerrainEditor():
m_bDrawChunkEdge( TRUE )
{
//	g_pDevice->CreateVertexBuffer( MAX_RANGE_MEM*sizeof(SVtxDiff), 0, SVtxDiff::FVF, 
//		D3DPOOL_MANAGED, &m_pRangeVtxBuff, NULL );
//	g_pDevice->CreateIndexBuffer( MAX_RANGE_MEM*sizeof(WORD), D3DUSAGE_WRITEONLY, 
//		D3DFMT_INDEX16, D3DPOOL_MANAGED, &m_pRangeIdxBuff, NULL );
//	m_RangeIdxSize = 0;

	m_TerrainEditCursor.Create(0, MAX_RANGE_MEM, sizeof(SVtxDiff), SVtxDiff::FVF, MAX_RANGE_MEM);
	m_TerrainEditCursor.setVtxBuffCount(0);
	m_TerrainEditCursor.setIdxBuffCount(0);

}


CTerrainEditor::~CTerrainEditor()
{
	HoverItor itor = m_HoverList.begin();
	while( m_HoverList.end() != itor )
		delete (itor++)->pModel;
	m_HoverList.clear();
}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
BOOL CTerrainEditor::Create( SCrTerrain *pCrInfo )
{
	m_nVtxCount = pCrInfo->nVtxPerRow * pCrInfo->nVtxPerCol;

	SAFE_ADELETE( m_pTLoader );
	m_pTLoader = (STerrainLoader*)new BYTE[ sizeof(STerrainLoader) + (m_nVtxCount* sizeof(float))];
	ZeroMemory( m_pTLoader, sizeof(STerrainLoader) );

	m_pTLoader->nWidth = pCrInfo->nWidth;
	m_pTLoader->nHeight = pCrInfo->nHeight;
	m_fHeightScale = 1.f;
	m_pTLoader->nVtxPerRow = pCrInfo->nVtxPerRow;
	m_pTLoader->nVtxPerCol = pCrInfo->nVtxPerCol;
	m_pTLoader->nCellPerRow = pCrInfo->nVtxPerRow - 1;
	m_pTLoader->nCellPerCol = pCrInfo->nVtxPerCol - 1;
	m_pTLoader->nCellSize = pCrInfo->nWidth / m_pTLoader->nCellPerCol;
	m_nTriCount = m_pTLoader->nCellPerRow * m_pTLoader->nCellPerCol * 2;
	m_pTLoader->nMapSize = m_nVtxCount;
	m_pTLoader->pMap = (float*)((BYTE*)m_pTLoader + sizeof(STerrainLoader));
	ZeroMemory( m_pTLoader->pMap, m_nVtxCount * sizeof(float) );

//	if( m_pTLoader->pMap ) 
//		delete[] m_pTLoader->pMap;
//	m_pTLoader->pMap = new float[ m_nVtxCount];
//	ZeroMemory( m_pTLoader->pMap, m_nVtxCount * sizeof(float) );

//	m_vecHeight.resize( m_nVtxCount );
//	for( int i=0; i < m_vecHeight.size(); ++i )
//		m_pTLoader->pMap[ i] = 0.f;
//		m_vecHeight[ i] = 0.f;

	if( !CreateVertex() )
		return FALSE;

	if( !CreateIndex() )
		return FALSE;

	return TRUE;
}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
BOOL CTerrainEditor::Save( char *szFileName )
{
//	STerrainLoader tloader;
//	ZeroMemory( &tloader, sizeof(tloader) );
//	tloader = m_TLoader;
//	tloader.nMapSize = m_pTLoader->nMapSize;
//	tloader.pMap = m_pTLoader->pMap;

/*
	// rigid ����
	tloader.nRigidSize = m_RigidList.size();
	if( 0 < m_RigidList.size() )
	{
		tloader.pRigid = new STModelLoader[ m_RigidList.size()];

		int i=0;
		ModelItor itor = m_RigidList.begin();
		while( m_RigidList.end() != itor )
		{
			Vector3 v;
			itor->pModel->GetPos( &v );
			tloader.pRigid[ i++] = STModelLoader( v, itor->nModelIdx, itor->szObjName );
			++itor;
		}
	}

	// dyn ����
	tloader.nDynSize = m_DynList.size();
	if( 0 < m_DynList.size() )
	{
		tloader.pDyn = new STModelLoader[ m_DynList.size()];

		int i=0;
		ModelItor itor = m_DynList.begin();
		while( m_DynList.end() != itor )
		{
			Vector3 v;
			itor->pModel->GetPos( &v );
			tloader.pRigid[ i++] = STModelLoader( v, itor->nModelIdx, itor->szObjName );
			++itor;
		}
	}
/**/

	CLinearMemLoader loader;
	loader.LoadTokenFile( "script//token_map.txt" );

	FILE *fp;
	fopen_s( &fp, szFileName, "wb" );
	// header
	fputc( 'm', fp );
	fputc( 'a', fp );
	fputc( 'p', fp );
//	loader.Write( fp, m_pTLoader, "TERRAIN" );
	loader.WriteScript( fp, m_pTLoader, "TERRAIN", 0 );
	fclose( fp );

	return TRUE;
}


//-----------------------------------------------------------------------------//
// ���
//-----------------------------------------------------------------------------//
void CTerrainEditor::Render()
{
	CTerrain::Render();

	if( m_bDrawChunkEdge )
		RenderChunkEdge();

	RenderHeightRange();

/*
	HoverItor itor = m_HoverList.begin();
	while( m_HoverList.end() != itor )
		(itor++)->pModel->Render();

	itor = m_CaptureList.begin();
	while( m_CaptureList.end() != itor )
		(itor++)->pModel->RenderBoundBox();
/**/
}


//-----------------------------------------------------------------------------//
// ���ϸ��̼�
//-----------------------------------------------------------------------------//
void CTerrainEditor::Update( int nElapsTick )
{
	CTerrain::Update( nElapsTick );

//	HoverItor itor = m_HoverList.begin();
//	while( m_HoverList.end() != itor )
//		(itor++)->pModel->Update( nElapsTick );
}


//-----------------------------------------------------------------------------//
// Terrain Height ����
//-----------------------------------------------------------------------------//
void CTerrainEditor::SetHeightMapEntry( int nRow, int nCol, float fHeight )
{
//	m_vecHeight[ nRow * m_pTLoader->nVtxPerCol + nCol] = fHeight;
	m_pTLoader->pMap[ nRow * m_pTLoader->nVtxPerCol + nCol] = fHeight;

}


//-----------------------------------------------------------------------------//
// ���� ����
// vPos: map x,y axis
// eType: cursor type {square, circle}
// fSize: up/down cursor size
//-----------------------------------------------------------------------------//
void CTerrainEditor::SetHeight( Vector2 vPos, CURSOR_TYPE eType, float fCursorSize, float fHeightOffset )
{
	int i=0;
	SVertex *pv = NULL;
	WORD *pi = NULL;
	const int tricnt = m_nTriCount*3;
	m_pVtxBuff->Lock( 0, 0, (void**)&pv, 0 );
	m_pIdxBuff->Lock( 0, 0, (void**)&pi, 0 );

	int cursor_vtx_size = 0;
	int cursor_idx_size = 0;
	std::map< int, int > idxmap;
	SVtxDiff *prv = NULL;
	WORD *pri = NULL;

	IDirect3DVertexBuffer9 *pVtxBuff = m_TerrainEditCursor.getVtxBuffer();
	IDirect3DIndexBuffer9 *pIdxBuff = m_TerrainEditCursor.getIdxBuffer();
	pVtxBuff->Lock( 0, 0, (void**)&prv, 0 );
	pIdxBuff->Lock( 0, 0, (void**)&pri, 0 );

	for( i=0; i < tricnt; i+=3 )
	{
		Vector3 v1 = pv[ pi[ i]].vP;
		Vector3 v2 = pv[ pi[ i+1]].vP;
		Vector3 v3 = pv[ pi[ i+2]].vP;
//		v1.z = 0.f;
//		v2.z = 0.f;
//		v3.z = 0.f;

		Triangle tri( v1, v2, v3 );
		const float offsetLength = v1.Distance(v2);
		float len = tri.Distance( Vector3(vPos.x, (v1.y+v2.y+v3.y)/3.f, vPos.y) );
//		float len = tri.Distance( Vector3(vPos.x, 0.f, vPos.y) );
		if( fCursorSize + offsetLength <= fabs(len) ) continue;

		// ���� Circle ����
		for( int k=0; k < 3; ++k )
		{
			const int index_alpha[ 3] = {0,1,2};

			int new_vtxidx = 0;
			const int src_vtx_index = pi[ i+index_alpha[k]];
			// key=src vertex index, value=new vertex index
			std::map<int,int>::iterator it = idxmap.find( src_vtx_index );
			if( idxmap.end() == it )
			{
				idxmap[ src_vtx_index] = cursor_vtx_size;
				new_vtxidx = cursor_vtx_size;

				Vector3 v1 = pv[ src_vtx_index].vP;
				Vector2 dv( v1.x - vPos.x, v1.z - vPos.y );
				const float length = dv.Length();
				if( 0.f < fCursorSize-length )
				{
					// Terrain ���� ������Ʈ
					pv[ src_vtx_index].vP.y += fHeightOffset * (fCursorSize-length) / fCursorSize;
				}

				prv[ new_vtxidx].v = pv[ src_vtx_index].vP;
				prv[ new_vtxidx].c = D3DXCOLOR( 0, .3f, 0, 0 );
				prv[ new_vtxidx].v.y += 1.3f;
				++cursor_vtx_size;
			}
			else
			{
				new_vtxidx = it->second;
			}

			pri[ cursor_idx_size++] = new_vtxidx;
		}
	}

	m_TerrainEditCursor.setVtxBuffCount(cursor_vtx_size);
	m_TerrainEditCursor.setIdxBuffCount(cursor_idx_size/3);

	m_pVtxBuff->Unlock();
	m_pIdxBuff->Unlock();
	pIdxBuff->Unlock();
	pVtxBuff->Unlock();

	//ApplyHeightToChunk( &m_TerrainEditCursor );
}


//-----------------------------------------------------------------------------//
// ���� Ư����ġ�� ���ؽ�, �ε��� ������ �����Ѵ�.
// vPos : ��ũ�� ��ǥ
// fCircleSize : ��ũ�� ��ǥ�� �߽����� �� ���� ������ ũ��
// pMapMesh : vPos, fCircleSize �� �ش��ϴ� �� ������ �����ؼ� ���ϵȴ�.
//-----------------------------------------------------------------------------//
void CTerrainEditor::getMapVertex( Vector2 vPos, float fCircleSize, CMesh *pMapMesh )
{
	int i=0;
	SVertex *pv = NULL;
	WORD *pi = NULL;
	const int tricnt = m_nTriCount*3;
	m_pVtxBuff->Lock( 0, 0, (void**)&pv, 0 );
	m_pIdxBuff->Lock( 0, 0, (void**)&pi, 0 );

	int range_vtx_size = 0;
	int range_idx_size = 0;
	std::map< int, int > idxmap;
	SVtxDiff *prv = NULL;
	WORD *pri = NULL;

	IDirect3DVertexBuffer9 *pVtxBuff = pMapMesh->getVtxBuffer();
	IDirect3DIndexBuffer9 *pIdxBuff = pMapMesh->getIdxBuffer();
	pVtxBuff->Lock( 0, 0, (void**)&prv, 0 );
	pIdxBuff->Lock( 0, 0, (void**)&pri, 0 );

	for( i=0; i < tricnt; i+=3 )
	{
		Vector3 v1 = pv[ pi[ i]].vP;
		Vector3 v2 = pv[ pi[ i+1]].vP;
		Vector3 v3 = pv[ pi[ i+2]].vP;

		Triangle tri( v1, v2, v3 );
		float len = tri.Distance( Vector3(vPos.x, (v1.y+v2.y+v3.y)/3.f, vPos.y) );
		if( fCircleSize <= fabs(len) ) continue;

		// ���� Circle ����
		for( int k=0; k < 3; ++k )
		{
			const int index_alpha[ 3] = {0,1,2};
			int new_vtxidx = 0;
			int vertex_index = pi[ i+index_alpha[k]];
			// key=src vertex index, value=new vertex index
			std::map<int,int>::iterator it = idxmap.find( vertex_index );
			if( idxmap.end() == it )
			{
				idxmap[ vertex_index] = range_vtx_size;
				new_vtxidx = range_vtx_size;

				// ���� ������Ʈ
				Vector3 v1 = pv[ vertex_index].vP;
				Vector2 dv( v1.x - vPos.x, v1.z - vPos.y );
//				float length = dv.Length();
//				if( 0.f < fSize-length ) pv[ vertex_index].vP.y += fHeightOffset * (fSize-length) / fSize;

				prv[ new_vtxidx].v = pv[ vertex_index].vP;
				prv[ new_vtxidx].c = D3DXCOLOR( 0, .3f, 0, 0 );
				prv[ new_vtxidx].v.y += 1.3f;
				++range_vtx_size;
			}
			else
			{
				new_vtxidx = it->second;
			}

			pri[ range_idx_size++] = new_vtxidx;
		}
	}

	pMapMesh->setVtxBuffCount(range_vtx_size);
	pMapMesh->setIdxBuffCount(range_idx_size/3);

	m_pVtxBuff->Unlock();
	m_pIdxBuff->Unlock();
	pIdxBuff->Unlock();
	pVtxBuff->Unlock();

}


//-----------------------------------------------------------------------------//
// HoverObj�� ����Object�� �߰��Ѵ�.
//-----------------------------------------------------------------------------//
BOOL CTerrainEditor::LocateModel( Vector2 vPos )
{
	HoverItor itor = m_HoverList.begin();
	while( m_HoverList.end() != itor )
	{
		AddTModel( vPos, itor->eOType, itor->szObjName, itor->pModel );
		++itor;
	}

	return TRUE;
}


//-----------------------------------------------------------------------------//
// Capture�� Model�� HoverList�� �߰��Ѵ�.
// 
//-----------------------------------------------------------------------------//
BOOL CTerrainEditor::CaptureToHover( LPPOINT lpPos )
{
	HoverCancel();
/*
	HoverItor itor = m_CaptureList.begin();
	while( m_CaptureList.end() != itor )
	{
		// �ӽ��ڵ� {�ϳ��� �����Ѵ�.}
		SHoverObj hover;
		hover.eOType = itor->eOType;
		hover.pModel = CopyModel( itor->eOType, itor->pModel );
		m_HoverList.push_back( hover );

		DelTModel( itor->eOType, itor->nId );

		++itor;
		break;
	}
	m_CaptureList.clear();
/**/
	return TRUE;
}


//-----------------------------------------------------------------------------//
// Hover �̵�
//-----------------------------------------------------------------------------//
void CTerrainEditor::MoveHoverObj( Vector2 vPos )
{
/*	HoverItor itor = m_HoverList.begin();
	while( m_HoverList.end() != itor )
	{
		(itor++)->pModel->SetPos( &Vector3(vPos.x,vPos.y, GetHeight(vPos.x,vPos.y) ) );
		g_Dbg.Console( "%f %f %f\n", vPos.x,vPos.y, GetHeight(vPos.x,vPos.y) );
	}
/**/
}


//-----------------------------------------------------------------------------//
// Dyn, Rigid Model capture�˻�
// return 0 = capture �ȵ�
//		  1 = Dyn,Rigid Capture
//		  2 = Hover ������
//-----------------------------------------------------------------------------//
int CTerrainEditor::Capture( LPRECT lpRect )
{
/*
	// Capture�� Model�� �ٽ� capture�� ��� CaptureToHover() �Լ��� ȣ��ǰ� ���ϵȴ�.
	HoverItor citor = m_CaptureList.begin();
	while( m_CaptureList.end() != citor )
	{
		if( citor->pModel->Pick(lpRect) )
		{
			POINT pos = {lpRect->left, lpRect->top};
			CaptureToHover( &pos );
			return 2;
		}
		++citor;
	}
	//

	// m_DynList �˻�
	m_CaptureList.clear();
	ModelItor itor = m_DynList.begin();
	while( m_DynList.end() != itor )
	{
		if( itor->pModel->Pick(lpRect) )
			m_CaptureList.push_back( SHoverObj(itor->nId,OT_MODEL,itor->szObjName,itor->pModel) );
		++itor;
	}

	// m_RigidList �˻�
	itor = m_RigidList.begin();
	while( m_RigidList.end() != itor )
	{
		if( itor->pModel->Pick(lpRect) )
			m_CaptureList.push_back( SHoverObj(itor->nId,OT_RIGID,itor->szObjName,itor->pModel) );
		++itor;
	}

	return (m_CaptureList.size()>0)? 1 : 0;
/**/

	return 0;
}


//-----------------------------------------------------------------------------//
// HoverObject �����
//-----------------------------------------------------------------------------//
void CTerrainEditor::HoverCancel()
{
	HoverItor itor = m_HoverList.begin();
	while( m_HoverList.end() != itor )
		delete (itor++)->pModel;
	m_HoverList.clear();
}


//-----------------------------------------------------------------------------//
// Hover Object ����
//-----------------------------------------------------------------------------//
void CTerrainEditor::SetHover( OBJ_TYPE eOType, char *szObjName )
{
/*
	CModel *pModel = NULL;
	if( eOType == OT_MODEL )
	{
		pModel = new SD_CDynModel;
		pModel->Load( szObjName );
	}
	else if( eOType == OT_RIGID )
	{
		pModel = new SD_CRigidModel;
		pModel->Load( szObjName );
	}
	else
	{
		return;
	}

	m_HoverList.push_back( SHoverObj(0,eOType,szObjName,pModel) );
/**/

}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
void CTerrainEditor::UpdateObjPos()
{
/*
	ModelItor itor = m_DynList.begin();
	while( m_DynList.end() != itor )
	{
		Vector3 vPos;
		itor->pModel->GetPos( &vPos );
		itor->pModel->SetPos( &Vector3(vPos.x, vPos.y, GetHeight(vPos.x,vPos.y)) );
		++itor;
	}

	itor = m_RigidList.begin();
	while( m_RigidList.end() != itor )
	{
		Vector3 vPos;
		itor->pModel->GetPos( &vPos );
		itor->pModel->SetPos( &Vector3(vPos.x, vPos.y, GetHeight(vPos.x,vPos.y)) );
		++itor;
	}
/**/

}


//-----------------------------------------------------------------------------//
// ��ũ������ ��ǥ�� Pick()�� ���� ������ ���� ��ǥ�� ������ �ش� ûũ�� �����Ѵ�.
// pos: ��ũ�� ��ǥ
// pu, pv: ûũ���� UV��ǥ�� �����Ѵ�.
//-----------------------------------------------------------------------------//
CChunk* CTerrainEditor::GetChunkFrom2D( Vector2 screenpos, float *pu, float *pv ) // pu,pv=NULL
{
	Vector3 pick;
	if( !Pick(&screenpos, &pick) )
		return NULL;

	return GetChunkFrom3D( pick, pu, pv );
}

//-----------------------------------------------------------------------------//
// 3�������� ����ǥ�� �������� �ش� ûũ�� �����Ѵ�.
// pos: 3���� ���� ��ǥ
// pu, pv: ûũ���� UV��ǥ�� �����Ѵ�.
//-----------------------------------------------------------------------------//
CChunk* CTerrainEditor::GetChunkFrom3D( Vector3 pos, float *pu, float *pv ) // pu,pv=NULL
{
	// ��� ûũ�� Ŭ���Ǿ����� ã�´�. x,z������ ã��������
	const float map_width = (float)(m_pTLoader->nVtxPerCol-1) * (float)m_pTLoader->nCellSize;
	const float map_height = (float)(m_pTLoader->nVtxPerRow-1) * (float)m_pTLoader->nCellSize;
	const float chunk_width = map_width / (float)CHUNK_COL;
	const float chunk_height = map_height / (float)CHUNK_ROW;
	
	int cx_idx = (int)((pos.x + (map_width / 2.f)) / chunk_width);
	int cy_idx = (int)((pos.z + (map_height / 2.f)) / chunk_height);

	//-----------------------------------------------------------------
	// ���� ������ ���� ���κа� ���� �Ʒ��κ��� Ŭ���Ǿ����� ���õǴ� 
	// ������ �ذ���
	if( CHUNK_COL == cx_idx )
	{
//		if( 0.1f > fabs((pos.x + (map_width / 2.f)) - map_width) )
//			cx_idx -= 1;
	}
	if( CHUNK_ROW == cy_idx )
	{
//		if( 0.1f > fabs((pos.z + (map_height / 2.f)) - map_height) )
//			cy_idx -= 1;
	}
	//-----------------------------------------------------------------

	if( (0 > cx_idx) || (CHUNK_COL < cx_idx) ) return NULL;
	if( (0 > cy_idx) || (CHUNK_ROW < cy_idx) ) return NULL;

	// ������ ���� 0,0�� ��Ÿ���� ������ �ε�������� �ѹ��� ���־�� �Ѵ�.
//	cx_idx = CHUNK_COL - cx_idx - 1;
	cy_idx = CHUNK_ROW - cy_idx - 1;

	// �ؽ��� uv��ǥ�� ��´�.
//	const float chunk_x = ((CHUNK_COL - cx_idx - 1) * chunk_width);
	const float chunk_x = (cx_idx * chunk_width);
	const float chunk_y = ((CHUNK_ROW - cy_idx - 1) * chunk_height);
	const float pick_u = (pos.x + (map_width / 2.f)) - chunk_x;
	const float pick_v = (pos.z + (map_height / 2.f)) - chunk_y;
	if( pu ) 
		*pu = pick_u / chunk_width;
	if( pv )
		*pv = 1.f - (pick_v / chunk_height);

	return &m_Chunk[ cx_idx][ cy_idx];
}

//-----------------------------------------------------------------------------//
// ûũ ���� �������� ûũ������ �����Ѵ�.
// x,y: m_Chunk[ x][ y]
//-----------------------------------------------------------------------------//
CChunk* CTerrainEditor::GetChunkFromAxis( int x, int y )
{
	if( (0 > x) || (x >= CHUNK_COL) ) return NULL;
	if( (0 > y) || (y >= CHUNK_ROW) ) return NULL;
	return &m_Chunk[ x][ y];
}


//-----------------------------------------------------------------------------//
// ûũ ����
// x,y: m_Chunk[ x][ y]
//-----------------------------------------------------------------------------//
BOOL CTerrainEditor::SetChunk( int x, int y, CChunk *pchunk )
{
	if( (0 > x) || (x >= CHUNK_COL) ) return FALSE;
	if( (0 > y) || (y >= CHUNK_ROW) ) return FALSE;
	m_Chunk[ x][ y] = *pchunk;
	return TRUE;
}


//-----------------------------------------------------------------------------//
// ûũ ����ȭ
//-----------------------------------------------------------------------------//
void CTerrainEditor::OptimizeChunk()
{

}


//-----------------------------------------------------------------------------//
// �ش� ûũ�� ���̾� layeridx�� ���� �Ѵ�. 
// ���̾ ���ŵ��� �������� �ٽ� ���ĵȴ�.
// pchunk: ���̾ ���� ûũ
// layeridx: ������ ���̾�
//-----------------------------------------------------------------------------//
BOOL CTerrainEditor::DeleteLayer( CChunk *pchunk, int layeridx )
{
	if( !pchunk ) return FALSE;
	if( (pchunk->m_layerCount <= layeridx) || (0 > layeridx) ) return FALSE;

	SAFE_RELEASE( pchunk->layer[ layeridx].palpha );
	SAFE_ADELETE( pchunk->layer[ layeridx].palphaname );
	SAFE_ADELETE( pchunk->layer[ layeridx].ptexturename );

	// layer�� ��ĭ�� ������ �̵�
	for( int i=layeridx+1; i < pchunk->m_layerCount; ++i )
		pchunk->layer[ i-1] = pchunk->layer[ i];

	--pchunk->m_layerCount;
	if( 0 > pchunk->m_layerCount ) 
		pchunk->m_layerCount = 0;
	return TRUE;
}


//-----------------------------------------------------------------------------//
// �ΰ��� ���̾ �ϳ��� ��ģ��.
// ���յ� ���̾ �ٸ� �ؽ��ĸ� �����ٸ�, �Լ��� �����ϰ� ���ϵȴ�.
// �ΰ��� ���̾��� ���İ��� ADD���꿡 ���� ���յȴ�.
// pchunk: ���յ� ���̾ ���� ûũ
// layeridx_from: ���յ� ���̾�, ���յǰ� ��������.
// layeridx_to: ���յ� ���̾�, �״�� �����ִ´�.
//-----------------------------------------------------------------------------//
BOOL CTerrainEditor::MergeLayer( CChunk *pchunk, int layeridx_from, int layeridx_to )
{
	if( !pchunk ) return FALSE;
	if( (pchunk->m_layerCount <= layeridx_from) || (0 > layeridx_from) ) return FALSE;
	if( (pchunk->m_layerCount <= layeridx_to) || (0 > layeridx_to) ) return FALSE;

	// ���� �ؽ������� �˻�
	if( strcmp(pchunk->layer[ layeridx_from].ptexturename, pchunk->layer[ layeridx_to].ptexturename) )
		return FALSE;

	// ���İ� �ռ�
	//-------------------------------------------------------------
	// ���� �������� ����
	//-------------------------------------------------------------

	// ���յǰ� ���� ���̾�� ���ŵȴ�.
	DeleteLayer( pchunk, layeridx_from );

	return TRUE;
}


//-----------------------------------------------------------------------------//
// layeridx_to�� layeridx_from�� ���̾ �̵���Ű�� ������ ���̾�� ��ĭ��
// �и���.
// pchunk: �̵��� ���̾ ���� ûũ
// layeridx_from: �̵��� ���̾� �ε���
// layeridx_to: ��ġ�� ���̾� �ε���
//-----------------------------------------------------------------------------//
BOOL CTerrainEditor::MoveLayer( CChunk *pchunk, int layeridx_from, int layeridx_to )
{
	if( !pchunk ) return FALSE;
	if( (pchunk->m_layerCount <= layeridx_from) || (0 > layeridx_from) ) return FALSE;
	if( (pchunk->m_layerCount <= layeridx_to) || (0 > layeridx_to) ) return FALSE;
	if( layeridx_from == layeridx_to ) return TRUE;

	CChunk::SLayer layer = pchunk->layer[ layeridx_from];
	DeleteLayer( pchunk, layeridx_from );
	InsertLayer( pchunk, layeridx_to, &layer );

	return TRUE;
}


//-----------------------------------------------------------------------------//
// ���̾ insert_layeridx ��ġ�� �����ϰ�, ������ ���̾���� �ڷ� ��ĭ�� 
// �и���.
// pchunk: ������ ���̾ ���� ûũ 
// insert_layeridx: ������ ���̾� �ε���
// player: ������ ���̾� ����
//-----------------------------------------------------------------------------//
BOOL CTerrainEditor::InsertLayer( CChunk *pchunk, int insert_layeridx, CChunk::SLayer *player )
{
	if( !pchunk ) return FALSE;
	if( (pchunk->m_layerCount < insert_layeridx) || (0 > insert_layeridx) ) return FALSE;
	if( MAX_LAYER_CNT <= insert_layeridx ) return FALSE;
	if( MAX_LAYER_CNT <= pchunk->m_layerCount ) return FALSE;
	
	// layer�� ��ĭ�� ������ �̵�
	for( int i=insert_layeridx; i < pchunk->m_layerCount+1; ++i )
		pchunk->layer[ i+1] = pchunk->layer[ i];
	
	// ����
	pchunk->layer[ insert_layeridx] = *player;
	++pchunk->m_layerCount;

	return TRUE;
}


//-----------------------------------------------------------------------------//
// ���̾� �߰�, �����ؽ��ĸ� �����Ѵ�.
// pchunk: ���̾ �߰��� ûũ
// player: �߰��� ���̾� ����
//-----------------------------------------------------------------------------//
BOOL CTerrainEditor::AddLayer( CChunk *pchunk )
{
	if( !pchunk ) return FALSE;
	if( MAX_LAYER_CNT <= pchunk->m_layerCount ) return FALSE;

	// Create Alpha Texture
	g_pDevice->CreateTexture( 32, 32, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, 
		&pchunk->layer[ pchunk->m_layerCount].palpha, NULL );
	D3DLOCKED_RECT lockrect;
	pchunk->layer[ pchunk->m_layerCount].palpha->LockRect( 0, &lockrect, NULL, 0 );
	memset( lockrect.pBits, 0x0, lockrect.Pitch*32 );
	pchunk->layer[ pchunk->m_layerCount].palpha->UnlockRect( 0 );

	pchunk->layer[ pchunk->m_layerCount].flag = CChunk::VISIBLE | CChunk::EDIT;
	pchunk->layer[ pchunk->m_layerCount].palphaname = new char[ 128];
	pchunk->layer[ pchunk->m_layerCount].ptexturename = new char[ 128];

	++pchunk->m_layerCount;
	return TRUE;
}


//-----------------------------------------------------------------------------//
// Ÿ�� ������ ���
//-----------------------------------------------------------------------------//
void CTerrainEditor::setVisibleBrush( BOOL visible )
{
	


}


//-----------------------------------------------------------------------------//
// �귯���� ������ ����Ѵ�.
//-----------------------------------------------------------------------------//
void CTerrainEditor::MoveBrush( SBrushInfo *pbrush, Vector2 screenpos )
{
//	getMapVertex(screenpos, pbrush->radius, &m_HeightRange);
	getMapVertex(screenpos, 20.f, &m_TerrainEditCursor);


}


//-----------------------------------------------------------------------------//
// ���÷��� ����� ������ �ؽ��ĸ� ������.
// pbrush: �귯�� ����
// screenpos: �귯���� �׸� ��ũ�� ��ǥ
//-----------------------------------------------------------------------------//
BOOL CTerrainEditor::DrawBrush( SBrushInfo *pbrush, Vector2 screenpos )
{
	if( !pbrush->load )
	{
		::AfxMessageBox( "Ÿ���� ���� �����ϼ���" );
		return FALSE;
	}

	// focus flag �ʱ�ȭ
	int i=0;
	for( i=0; i < CHUNK_ROW; ++i )
	{
		for( int k=0; k < CHUNK_COL; ++k )
			m_Chunk[ k][ i].m_Flag = m_Chunk[ k][ i].m_Flag & ~(DWORD)(CChunk::FOCUS1 | CChunk::FOCUS2);
	}

	float cu, cv;
	CChunk *pcenter_chunk = GetChunkFrom2D( screenpos, &cu, &cv );
	if( !pcenter_chunk ) return FALSE;

	int cx_idx = pcenter_chunk->m_x;
	int cy_idx = pcenter_chunk->m_y;

	// Ŭ���� ûũ �ֺ� ûũ�� ��� �˻��Ѵ�. (�� 9��)
	POINT idx_offset[] = // x,y
	{
		{-1,-1}, {0,-1}, {1,-1},
		{-1,0}, {0,0}, {1,0},
		{-1,1}, {0,1}, {1,1},
	};
	Vector2 c_point[9];
	c_point[ 0] = Vector2( -0.5f,-0.5f ); c_point[ 1] = Vector2( 0.5f,-0.5f ); c_point[ 2] = Vector2( 1.5f,-0.5f );
	c_point[ 3] = Vector2( -0.5f, 0.5f ); c_point[ 4] = Vector2( 0.5f, 0.5f ); c_point[ 5] = Vector2( 1.5f, 0.5f );
	c_point[ 6] = Vector2( -0.5f, 1.5f ); c_point[ 7] = Vector2( 0.5f, 1.5f ); c_point[ 8] = Vector2( 1.5f, 1.5f );

	for( i=0; i < sizeof(idx_offset)/sizeof(POINT); ++i )
	{
		// real x,y index
		const int rx_idx = cx_idx + idx_offset[ i].x;
		const int ry_idx = cy_idx + idx_offset[ i].y;
		if((0 > rx_idx) || (CHUNK_COL <= rx_idx)) continue;
		if((0 > ry_idx) || (CHUNK_ROW <= ry_idx)) continue;

		CChunk *pchunk = &m_Chunk[ rx_idx][ ry_idx];
		pchunk->m_Flag |= CChunk::FOCUS2;

		const float u = cu - (float)idx_offset[ i].x;
		const float v = cv - (float)idx_offset[ i].y;

		if (!isInDrawBrush(pchunk, u-0.5f, v-0.5f, pbrush)) continue;

//		float len = sqrt( (cu-c_point[ i].x)*(cu-c_point[ i].x) + 
//						  (cv-c_point[ i].y)*(cv-c_point[ i].y) );
//		if( (0.72f < fabs(len - pbrush->radius)) )
//			continue;

		pchunk->m_Flag |= CChunk::FOCUS1;

		CChunk::SLayer *ptop = NULL;
		pchunk->m_Visible = TRUE;
		BOOL addlayer = FALSE;
		BOOL brush = FALSE;

		if( 0 == pchunk->m_layerCount )
		{
			addlayer = TRUE;
		}
		else
		{
			ptop = GetTopEditLayer( pchunk, pbrush );
			if( !ptop )
				addlayer = TRUE;
		}

		// �귯���� �ٸ� �ؽ��ĸ� ���ų�, ���̾ ���ٸ�,
		// ���� ���̾ �����.
		if( addlayer && !(pbrush->flag & SBrushInfo::ERASE) )
		{
			if( !AddLayer(pchunk) )
				continue;
			ptop = &pchunk->layer[ pchunk->m_layerCount-1];
			strcpy_s( ptop->ptexturename, 128, pbrush->texture );
			ptop->ptexture = CFileLoader::LoadTexture( (char*)(LPCTSTR)(CString(g_szTilePath) + CString("//") + pbrush->texture) );
		}

		// �����ؽ��Ŀ� �귯���Ѵ�.
		if( ptop )
		{
			Brush( u, v, pbrush, ptop->palpha );
		}
	}

	return TRUE;
}


//-----------------------------------------------------------------------------//
// pChunk�� �������� u,v ��ǥ�� �귯���� ������� �˷��ִ� �Լ���. 
// �귯���� ��´ٸ� true�� �����Ѵ�.
// pChunck : ���õ� ûũ
// u/v : ûũ�� ���������� u/v ��ǥ
// pbrush : �귯�� ����
//-----------------------------------------------------------------------------//
BOOL CTerrainEditor::isInDrawBrush(CChunk *pchunk, float u, float v, SBrushInfo *pbrush)
{
	const int LEFT_TOP = 0;
	const int RIGHT_TOP = 1;
	const int RIGHT_BOTTOM = 2;
	const int LEFT_BOTTOM = 3;
	const int LEFT = 0;
	const int TOP = 1;
	const int RIGHT = 2;
	const int BOTTOM = 3;

	int type = 0; // 0=leftTop, 1=rightTop, 2=rightBottom, 3=leftBottom
	if (u > 0.f && v > 0.f)
		type = RIGHT_BOTTOM; // rightBottom
	else if (u > 0.f && v < 0.f)
		type = RIGHT_TOP; // rightTop
	else if (u < 0.f && v > 0.f)
		type = LEFT_BOTTOM; // leftBottom
	else if (u < 0.f && v < 0.f)
		type = LEFT_TOP; // leftTop

	// ûũ �������� ���� ���⺤�͸� ����Ѵ�.
	Vector3 vtxNormal(1,0,1);
	switch(type) {
	case LEFT_TOP:		vtxNormal = Vector3(-1.f, 0, 1.f); break;
	case RIGHT_TOP:		vtxNormal = Vector3(1.f, 0, 1.f); break;
	case RIGHT_BOTTOM:	vtxNormal = Vector3(1.f, 0, -1.f); break;
	case LEFT_BOTTOM:	vtxNormal = Vector3(-1.f, 0, -1.f); break;
	}
	vtxNormal.Normalize();

	Vector3 dir(u, 0, -v); // uv��ǥ�� ����x,z ��ǥ���� v/z ��ǥ�� �ݴ밡 �Ǳ⶧���� -�� �ٿ���.
	const float length = dir.Length();
	dir.Normalize();
	Vector3 cross = dir.CrossProduct(vtxNormal);
	const BOOL leftSwing = cross.y < 0.f; // �������� ���� (���������� ��Ģ)

	// ûũ�� ��� ��� �´���� ����Ѵ�.
	int edgeType = 0; // 0=left, 1=top, 2=right, 3=bottom
	switch(type) {
	case LEFT_TOP:		edgeType = (leftSwing)? TOP : LEFT; break;
	case RIGHT_TOP:		edgeType = (leftSwing)? RIGHT : TOP; break;
	case RIGHT_BOTTOM:	edgeType = (leftSwing)? BOTTOM : RIGHT; break;
	case LEFT_BOTTOM:	edgeType = (leftSwing)? LEFT : BOTTOM; break;
	}

	// ûũ���� �������͸� ���Ѵ�. ������ ûũ�� �ٱ����� ���Ѵ�.
	Vector3 normal(0,0,1);
	switch(edgeType) {
	case LEFT:		normal = Vector3(-1.f,0,0); break;
	case TOP:		normal = Vector3(0,0,1.f); break;
	case RIGHT:		normal = Vector3(1.f,0,0); break;
	case BOTTOM:	normal = Vector3(0,0,-1.f); break;
	}

	float cosTheta = fabs(dir.DotProduct(normal));
	if (cosTheta <= 0.f) cosTheta = 0.00001f;
	const float len = 0.5f / cosTheta;

	const BOOL inChunck = ((length-len) < pbrush->radius);
	return inChunck;
}


//-----------------------------------------------------------------------------//
// �����ؽ����� x,y��ǥ��(2����) �귯���Ѵ�.
// u,v: �귯���� �����ؽ��� u,v��ǥ
// pbrush: �귯������ 
// palpha: �귯���ϰ��� �ϴ� �ؽ�������
//-----------------------------------------------------------------------------//
void CTerrainEditor::Brush( float u, float v, SBrushInfo *pbrush, IDirect3DTexture9 *palpha )
{
	// Create Alph Texture
	D3DLOCKED_RECT lockrect;
	palpha->LockRect( 0, &lockrect, NULL, 0 );

	BYTE *pbits = (BYTE*)lockrect.pBits;
	for( int ay=0; ay < 32; ++ay )
	{
		for( int ax=0; ax < 32; ++ax )
		{
			float au = (float)ax / 32.f;
			float av = (float)ay / 32.f;

			float len = sqrt( ((au-u)*(au-u)) + ((av-v)*(av-v)) );
			DWORD *ppixel = (DWORD*)(pbits + (ax*4) + (lockrect.Pitch * ay));
			int alpha = *ppixel >> 24;

			if( len <= pbrush->center_radius )
			{
				alpha = (int)(pbrush->center_alpha * 255.f);
				if( SBrushInfo::ERASE & pbrush->flag )
					alpha = 0;
			}
			else if( len <= pbrush->radius )
			{
				// ����
				float width = (pbrush->radius - pbrush->center_radius);
				float delta = 1.f - ((len - pbrush->center_radius) / width);
				float value = ((pbrush->center_alpha - pbrush->edge_alpha) * delta) * 255;

				if( SBrushInfo::ERASE & pbrush->flag )
				{
					if( (255-value) < alpha )
						alpha = (int)(255.f-value);
				}
				else
				{
					if( value > alpha )	
						alpha = (int)value;
				}
			}

			if( 0 > alpha ) alpha = 0;
			if( 255 < alpha ) alpha = 255;

			*ppixel = ((DWORD)alpha<<24) | (*ppixel&0x00ffffff);
		}
	}

	palpha->UnlockRect( 0 );
}


//-----------------------------------------------------------------------------//
// ������ �� �ִ� ���̾ �����Ѵ�.
// hide, no edit ������ ���̾�� ������ �� �����Ƿ� �ٸ� ���̾ ã�´�.
// �귯���� MATCH���¶�� ���̾�� �귯���� ���� �ؽ��� ���̾ ã�� �����Ѵ�.
// pchunk: ���̾ �����ϰ� �ִ� ûũ
//-----------------------------------------------------------------------------//
CChunk::SLayer* CTerrainEditor::GetTopEditLayer( CChunk *pchunk, SBrushInfo *pbrush )
{
	if( !pchunk ) return NULL;
	int cnt = pchunk->m_layerCount;
	for( int i=cnt-1; i >= 0; --i )
	{
		if( !(CChunk::VISIBLE & pchunk->layer[ i].flag) ||
			!(CChunk::EDIT & pchunk->layer[ i].flag) )
			continue;
		if( 
			// cond1
			// MATCH �϶�
			// �귯���� ���� �ؽ��ĸ� ���� ���̾ ã�� �����Ѵ�.
			( (SBrushInfo::MATCH & pbrush->flag) && 
			  (!strcmp(pbrush->texture, pchunk->layer[ i].ptexturename))) ||

			// cond2
			// ERASE �϶�
			// ž ���̾ �����Ѵ�.
			(!(SBrushInfo::MATCH & pbrush->flag) && 
			  (SBrushInfo::ERASE & pbrush->flag)) ||

			// cond3
			// MATCH, ERASE ��� �ƴҶ�
			// ž ���̾ �귯���� �ؽ��Ŀ� ���ٸ� �����ϰ�, 
			// �׷��� �ʴٸ� NULL�� �����Ѵ�.
			(!(SBrushInfo::MATCH & pbrush->flag) && 
			 !(SBrushInfo::ERASE & pbrush->flag) &&
			  (i == (cnt-1)) &&
			  (!strcmp(pbrush->texture, pchunk->layer[ i].ptexturename)))
			)
			return &pchunk->layer[ i];
	}
	return NULL;
}


//-----------------------------------------------------------------------------//
// ûũ �ܰ��� ���, ��Ŀ�̵� ûũ, Draw���� ûũ�� ����Ѵ�.
//-----------------------------------------------------------------------------//
void CTerrainEditor::RenderChunkEdge()
{
	DWORD edge_color = D3DXCOLOR( 1.f, 0, 1.f, 0 );
	DWORD draw_color = D3DXCOLOR( 0, 0, 1.f, 0 );


	// ûũ �ܰ��� ���
	int y=0;
	for( y=0; y < CHUNK_ROW; ++y )
	{
		for( int x=0; x < CHUNK_COL; ++x )
		{
			CChunk *pchunk = &m_Chunk[ x][ y];
			if( !pchunk->m_Visible ) continue;

			SVtxDiff *pvd = NULL;
			pchunk->m_pvtxBuff_Edge->Lock( 0, 0, (void**)&pvd, 0 );
			for( int i=0; i < 5; ++i )
				pvd[ i].c = edge_color;
			pchunk->m_pvtxBuff_Edge->Unlock();

			g_pDevice->SetTexture( 0, NULL );
			g_pDevice->SetTexture( 1, NULL );

			g_pDevice->SetStreamSource( 0, pchunk->m_pvtxBuff_Edge, 0, sizeof(SVtxDiff) );
			g_pDevice->SetFVF( SVtxDiff::FVF );
			g_pDevice->DrawPrimitive( D3DPT_LINESTRIP, 0, 4 );
		}
	}

	// ��Ŀ�̵� ûũ ���
	for( y=0; y < CHUNK_ROW; ++y )
	{
		for( int x=0; x < CHUNK_COL; ++x )
		{
			CChunk *pchunk = &m_Chunk[ x][ y];
			if( !pchunk->m_Visible ) continue;

			if( (CChunk::FOCUS1 & pchunk->m_Flag) )
			{
				SVtxDiff *pvd = NULL;
				pchunk->m_pvtxBuff_Edge->Lock( 0, 0, (void**)&pvd, 0 );
				for( int i=0; i < 5; ++i )
					pvd[ i].c = draw_color;
				pchunk->m_pvtxBuff_Edge->Unlock();

				g_pDevice->SetTexture( 0, NULL );
				g_pDevice->SetTexture( 1, NULL );
				
				g_pDevice->SetStreamSource( 0, pchunk->m_pvtxBuff_Edge, 0, sizeof(SVtxDiff) );
				g_pDevice->SetFVF( SVtxDiff::FVF );
				g_pDevice->DrawPrimitive( D3DPT_LINESTRIP, 0, 4 );
			}
		}
	}
}


//-----------------------------------------------------------------------------//
// ���ڷ� �Ѿ�� ûũ�� ��Ŀ�� ���·� �����Ѵ�.
// * ��Ŀ�̵Ǿ� �ִ� ûũ�� ��� �ʱ�ȭ ���� ���� ��Ŀ���� �����Ѵ�.
//-----------------------------------------------------------------------------//
void CTerrainEditor::SetFocusChunk( CChunk *pchunk )
{
	for( int i=0; i < CHUNK_ROW; ++i )
	{
		for( int k=0; k < CHUNK_COL; ++k )
			m_Chunk[ k][ i].m_Flag = m_Chunk[ k][ i].m_Flag & ~(DWORD)(CChunk::FOCUS1 | CChunk::FOCUS2);
	}

	if( !pchunk ) return;
	pchunk->m_Flag |= CChunk::FOCUS1;
}


//-----------------------------------------------------------------------------//
// Chunk Edge�� ��������� �����Ѵ�.
//-----------------------------------------------------------------------------//
void CTerrainEditor::SetDrawChunkEdgeOption( BOOL chunkdraw )
{
	m_bDrawChunkEdge = chunkdraw;
}


//-----------------------------------------------------------------------------//
// ���̹����� ������ ������ ûũ ���̰��� �����Ѵ�.
// pheightrage: ���̰� ����� ����
//-----------------------------------------------------------------------------//
void CTerrainEditor::ApplyHeightToChunk( CMesh *pterrainCursor )
{
	if( !pterrainCursor ) return;

	SVtxDiff *pvh = NULL;
	IDirect3DVertexBuffer9 *pvtxbuff = pterrainCursor->getVtxBuffer();
	int vtxSize = pterrainCursor->getVtxBuffCount();
	pvtxbuff->Lock( 0, 0, (void**)&pvh, 0 );

	for( int i=0; i < vtxSize; ++i )
	{
		SVtxDiff vtx = pvh[ i];
		float u,v;
		CChunk *pchunk = GetChunkFrom3D( vtx.v, &u, &v );
		if( !pchunk ) continue;

		CChunk *pchunktable[ 4];
		ZeroMemory( pchunktable, sizeof(pchunktable) );
		pchunktable[ 0] = pchunk;
		// ���� �ϳ��� �߽����� �ִ� ûũ 4���� �ߺ��� �� �ֱ� ������
		// ������ ûũ���� ��� �˻��Ѵ�.
		int offx=0, offy=0;
		if( 0.5f > u )
		{
			offx = 1;
			if( CHUNK_COL > pchunk->m_x + 1 )
				pchunktable[ 1] = &m_Chunk[ pchunk->m_x+1][ pchunk->m_y];
		}
		else
		{
			offx = -1;
			if( 0 <= pchunk->m_x - 1 )
				pchunktable[ 1] = &m_Chunk[ pchunk->m_x-1][ pchunk->m_y];
		}

		if( 0.5f > v )
		{
			offy = -1;
			if( 0 <= pchunk->m_y - 1 )
				pchunktable[ 2] = &m_Chunk[ pchunk->m_x][ pchunk->m_y-1];
		}
		else
		{
			offy = 1;
			if( CHUNK_ROW > pchunk->m_y + 1 )
				pchunktable[ 2] = &m_Chunk[ pchunk->m_x][ pchunk->m_y+1];
		}

		if( ((0 <= (pchunk->m_x + offx)) && (CHUNK_COL > (pchunk->m_x + offx))) &&
			((0 <= (pchunk->m_y + offy)) && (CHUNK_ROW > (pchunk->m_y + offy))) )
			pchunktable[ 3] = &m_Chunk[ pchunk->m_x+offx][ pchunk->m_y+offy];

		// TerrainCursor�� ������ ���� ������ �����ٸ� 
		// ���̰��� ������Ʈ �Ѵ�.
		for( int k=0; k < 4; ++k )
		{
			if( !pchunktable[ k] ) continue;
			CChunk *pcur = pchunktable[ k];
			if (!pcur->m_pvtxBuff) continue;
			const int vtxsize = (pcur->m_columnCellCount+1) * (pcur->m_rowCellCount+1);

			SVertex *pv = NULL;
			pcur->m_pvtxBuff->Lock( 0, 0, (void**)&pv, 0 );
			for( int m=0; m < vtxsize; ++m )
			{
				Vector3 v1( pv[ m].vP.x, 0, pv[ m].vP.z );
				Vector3 v2( vtx.v.x, 0, vtx.v.z );
				if( v1. EqualEpsilon(0.1f, v2) )
				{
					pv[ m].vP = vtx.v;
					pv[ m].vP.y -= 0.2f;
				}
			}
			pcur->m_pvtxBuff->Unlock();

			UpdateChunkEdge( pcur );
		}
	}

	pvtxbuff->Unlock();
}


//-----------------------------------------------------------------------------//
// HeightRange ���
//-----------------------------------------------------------------------------//
void CTerrainEditor::RenderHeightRange()
{
	g_pDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
	g_pDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
	g_pDevice->SetRenderState( D3DRS_SRCBLEND, D3DBLEND_ONE );
	g_pDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_DESTCOLOR );

	m_TerrainEditCursor.Render();

	g_pDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE );
	g_pDevice->SetRenderState( D3DRS_LIGHTING, TRUE );
}
