
#include "stdafx.h"
#include "global.h"
#include "terrain.h"
#include "fileloader.h"
#include <fstream>
#include <cmath>
#include <algorithm>
#include "model.h"
#include "quadtree.h"


using namespace std;

int CTerrain::m_nTModelId = 0;
CTerrain::CTerrain() : 
//m_pVHeap(NULL), m_pIB(NULL), m_pVB(NULL), m_pIHeap(NULL), m_pTexture(NULL), 
m_pVtxBuff(NULL), m_pIdxBuff(NULL), m_pTexture(NULL),
m_bFog(FALSE),
m_pTLoader(NULL), m_nRenderType( D3DPT_TRIANGLELIST ),
m_pQuadTree(NULL),
m_bLoaded(FALSE)
{

}


CTerrain::~CTerrain()
{
	SAFE_RELEASE( m_pVtxBuff );
	SAFE_RELEASE( m_pIdxBuff );
	SAFE_RELEASE( m_pDynamicIdxBuff );

	ModelItor itor = m_DynList.begin();
	while( m_DynList.end() != itor )
		delete (itor++)->pModel;
	m_DynList.clear();

	itor = m_RigidList.begin();
	while( m_RigidList.end() != itor )
		delete (itor++)->pModel;
	m_RigidList.clear();

	SAFE_ADELETE( m_pTLoader );
	SAFE_DELETE( m_pQuadTree );

	ClearChunk();

}


//-----------------------------------------------------------------------------//
// HeightFile Load (Raw format)
// szHeightFileName : Raw FileName
//-----------------------------------------------------------------------------//
BOOL CTerrain::Load( char *szHeightFileName, int nVtxRow, int nVtxCol, int nCellSize, float fHeightScale )
{
	m_bLoaded = TRUE;
	m_nVtxCount = nVtxRow * nVtxCol;

	SAFE_ADELETE( m_pTLoader );
	m_pTLoader = (STerrainLoader*)new BYTE[ sizeof(STerrainLoader) + (m_nVtxCount* sizeof(float))];
	ZeroMemory( m_pTLoader, sizeof(STerrainLoader) );

	const int cellPerRow = nVtxRow - 1;
	const int cellPerCol = nVtxCol - 1;

	m_pTLoader->nVtxPerRow = nVtxRow;
	m_pTLoader->nVtxPerCol = nVtxCol;
	m_pTLoader->nCellSize = nCellSize;
	m_fHeightScale = fHeightScale;
	m_pTLoader->nCellPerRow = cellPerRow;
	m_pTLoader->nCellPerCol = cellPerCol;
	m_pTLoader->nWidth = m_pTLoader->nCellPerRow * nCellSize;
	m_pTLoader->nHeight = m_pTLoader->nCellPerCol * nCellSize;
	m_nTriCount = m_pTLoader->nCellPerRow * m_pTLoader->nCellPerCol * 2;

	// chunk info
//	m_ColumnVtxCountPerChunk = nVtxCol / CHUNK_COL;
//	m_RowVtxCountPerChunk = nVtxRow / CHUNK_ROW;
	m_ColumnCellCountPerChunk = (cellPerCol / CHUNK_COL);
	m_RowCellCountPerChunk = (cellPerRow / CHUNK_ROW);
	m_ColumnVtxCountPerChunk = m_ColumnCellCountPerChunk + 1;
	m_RowVtxCountPerChunk = m_RowCellCountPerChunk + 1;

	m_Cell_Size = nCellSize;

//	if( !ReadRawFile(szHeightFileName) )
//		return FALSE;
	// scale heights
//	for(int i = 0; i < m_vecHeight.size(); i++)
//	{
//		float a = m_vecHeight[ i];
//		float b = a * fHeightScale;
//		m_vecHeight[ i] = b;
//	}

	if( !CreateVertex() )
		return FALSE;

	if( !CreateIndex() )
		return FALSE;

//	m_pTexture = CFileLoader::LoadTexture( "texture//�ڰ�.bmp" );
	m_pTexture = CFileLoader::LoadTexture( "map//tile//detail.tga" );
//	m_pTexture = CFileLoader::LoadTexture( "texture//bumpearth.jpg" );

	InitChunk();

	// Init QuadTree
	SAFE_DELETE( m_pQuadTree );
	m_pQuadTree = new CQuadTree( nVtxCol, nVtxRow );

	SVertex *pv = NULL;
	m_pVtxBuff->Lock( 0, 0, (void**)&pv, 0 );
	m_pQuadTree->Build( pv );
	m_pVtxBuff->Unlock();

//	m_Chunk[ 0][ 0].visible = TRUE;
//	m_Chunk[ 0][ 0].layercount = 1;
//	m_Chunk[ 0][ 0].layer[ 0].ptexture = CFileLoader::LoadTexture( "map//tile//terrain0.tga" );

//	m_Chunk[ 4][ 4].visible = TRUE;
//	m_Chunk[ 4][ 4].layercount = 1;
//	m_Chunk[ 4][ 4].layer[ 0].ptexture = CFileLoader::LoadTexture( "map//tile//radiation_box.tga" );

	return TRUE;
}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
BOOL CTerrain::Load( char *szFileName )
{
/*
	CLinearMemLoader loader;
	loader.LoadTokenFile( "script//token_map.txt" );

	FILE *fp = fopen( szFileName, "rb" );
	// header
	if( 'm' == fgetc(fp) && 'a' == fgetc(fp) && 'p' == fgetc(fp) )
		m_pTLoader = (STerrainLoader*)loader.Read( fp, "TERRAIN" );
	fclose( fp );

	if( !m_pTLoader ) return FALSE;

	m_fHeightScale = 1.0f;
	m_nVtxCount = m_pTLoader->nVtxPerRow * m_pTLoader->nVtxPerCol;
	m_nTriCount = m_pTLoader->nCellPerRow * m_pTLoader->nCellPerCol * 2;

	if( !CreateVertex() )
		return FALSE;

	if( !CreateIndex() )
		return FALSE;
/**/
	return TRUE;
}


//-----------------------------------------------------------------------------//
// Fog ����
//-----------------------------------------------------------------------------//
void CTerrain::SetFog( DWORD dwColor, float fMin, float fMax )
{
//	m_bFog = TRUE;
//	GetD3D()->SetFog( dwColor, fMin, fMax );
}


//-----------------------------------------------------------------------------//
// map�� ����� txture ������ �ε��Ѵ�.
//-----------------------------------------------------------------------------//
BOOL CTerrain::LoadTexture( char *szFileName )
{
/*
	m_pTexture = new Texture::CTexture;

	if( !Texture::ReadInFile("map", szFileName, Texture::NORMAL, m_pTexture) )
		return FALSE;
/**/
	return TRUE;
}


//-----------------------------------------------------------------------------//
// map�� ���̿����� texture�� �����Ѵ�.
//-----------------------------------------------------------------------------//
BOOL CTerrain::GenerateTexture()
{
/*
	if( !m_pTexture )
	{
		m_pTexture = new Texture::CTexture;
		m_pTexture->Create( m_pTLoader->nCellPerCol );
	}

	int nWidth = m_pTLoader->nCellPerCol;
	int nHeight = m_pTLoader->nCellPerRow;

	DWORD *pImage;
	m_pTexture->Lock( (BYTE**)&pImage );
	int nPitch = (nWidth + 3) & (~3);
	for( int i=0; i < nHeight; ++i )
	{
		for( int k=0; k < nWidth; ++k )
		{
			D3DXCOLOR c;
			float height = GetHeightMapEntry(i,k) / m_fHeightScale;

			if( (height) < 3.5f ) 		 c = D3DCOLOR_XRGB(255, 249, 157);
			else if( (height) < 7.0f )	 c = D3DCOLOR_XRGB(124, 197, 118);
			else if( (height) < 10.5f ) c = D3DCOLOR_XRGB(  0, 166,  81);
			else if( (height) < 12.0f ) c = D3DCOLOR_XRGB( 25, 123,  48);
			else if( (height) < 15.5f ) c = D3DCOLOR_XRGB(115, 100,  87);
			else c = D3DCOLOR_XRGB(255, 255, 255);

//			if( (height) < 42.5f ) 		 c = D3DCOLOR_XRGB(255, 249, 157);
//			else if( (height) < 85.0f )	 c = D3DCOLOR_XRGB(124, 197, 118);
//			else if( (height) < 127.5f ) c = D3DCOLOR_XRGB(  0, 166,  81);
//			else if( (height) < 170.0f ) c = D3DCOLOR_XRGB( 25, 123,  48);
//			else if( (height) < 212.5f ) c = D3DCOLOR_XRGB(115, 100,  87);
//			else c = D3DCOLOR_XRGB(255, 255, 255);

			pImage[i * nPitch + k] = (D3DCOLOR)c;
		}
	}
	m_pTexture->Unlock();
/**/

	return TRUE;
}


//-----------------------------------------------------------------------------//
// Raw �����б�
//-----------------------------------------------------------------------------//
BOOL CTerrain::ReadRawFile( char *szFileName )
{
/*
	vector<BYTE> in( m_nVtxCount );
	ifstream inFile( szFileName, ios_base::binary );
	if( inFile == 0 ) return FALSE;
	inFile.read( (char*)&in[0], in.size() );
	inFile.close();

//	m_vecHeight.resize( m_nVtxCount );
//	for( int i = 0; i < in.size(); i++ )
//		m_vecHeight[ i] = (float)in[ i];
/**/

	return TRUE;
}


//-----------------------------------------------------------------------------//
// Vertex Buffer ����
//-----------------------------------------------------------------------------//
BOOL CTerrain::CreateVertex()
{
	g_pDevice->CreateVertexBuffer( m_nVtxCount*sizeof(SVertex), 0, SVertex::FVF, D3DPOOL_MANAGED, &m_pVtxBuff, NULL );
	SVertex *pv = NULL;
	m_pVtxBuff->Lock( 0, 0, (void**)&pv, 0 );

	int startx = -m_pTLoader->nWidth / 2;
	int starty = m_pTLoader->nHeight / 2;
	int endx = m_pTLoader->nWidth / 2;
	int endy = -m_pTLoader->nHeight / 2;
	float uCoordIncrementSize = 1.0f / (float)m_pTLoader->nCellPerRow;
	float vCoordIncrementSize = 1.0f / (float)m_pTLoader->nCellPerCol;

	int i=0;
//	SVertex *pV = (SVertex*)m_pVB->Lock();
	for( int y=starty; y >= endy; y -= m_pTLoader->nCellSize, ++i )
	{
		int k=0;
 		for( int x=startx; x <= endx; x += m_pTLoader->nCellSize, ++k )
		{
			int index = i * m_pTLoader->nVtxPerRow + k;
//			pV[ index] = SVertex( x, y, m_vecHeight[ index], (float)k*uCoordIncrementSize, (float)i*vCoordIncrementSize );
//			pv[ index] = SVertex( x, y, m_pTLoader->pMap[ index], (float)k*uCoordIncrementSize, (float)i*vCoordIncrementSize );

//			pv[ index] = SVertex( x, 0, y, 1.f-(float)k*uCoordIncrementSize, 1.f-(float)i*vCoordIncrementSize );
			pv[ index] = SVertex( (float)x, 0.f, (float)y, (float)(k*uCoordIncrementSize), (float)(i*vCoordIncrementSize) );
		}
	}
	m_pVtxBuff->Unlock();

	return TRUE;
}


//-----------------------------------------------------------------------------//
// Index Buffer ����
//-----------------------------------------------------------------------------//
BOOL CTerrain::CreateIndex()
{
//	if( !m_pIHeap )
//	{
//		m_pIHeap = new IndexBuffer::CHeap();
//		m_pIHeap->Create( m_nTriCount * 3 );
//	}
//	m_pIB = m_pIHeap->Alloc( m_nTriCount * 3 );
//	WORD *pI = (WORD*)m_pIB->Lock();

	g_pDevice->CreateIndexBuffer( m_nTriCount*3*sizeof(WORD), D3DUSAGE_WRITEONLY, 
		D3DFMT_INDEX16, D3DPOOL_MANAGED, &m_pIdxBuff, NULL );

	g_pDevice->CreateIndexBuffer( m_nTriCount*3*sizeof(WORD), D3DUSAGE_WRITEONLY, 
		D3DFMT_INDEX16, D3DPOOL_MANAGED, &m_pDynamicIdxBuff, NULL );

	WORD *pi = NULL;
	m_pIdxBuff->Lock( 0, 0, (void**)&pi, 0 );

	int baseIndex = 0;
	for( int i=0; i < m_pTLoader->nCellPerRow; ++i )
	{
		for( int k=0; k < m_pTLoader->nCellPerCol; ++k )
		{
			pi[ baseIndex]     = (  i   * m_pTLoader->nVtxPerCol) + k;
			pi[ baseIndex + 1] = (  i   * m_pTLoader->nVtxPerCol) + k + 1;
			pi[ baseIndex + 2] = ((i+1) * m_pTLoader->nVtxPerCol) + k;

			pi[ baseIndex + 3] = ((i+1) * m_pTLoader->nVtxPerCol) + k;
			pi[ baseIndex + 4] = (  i   * m_pTLoader->nVtxPerCol) + k + 1;
			pi[ baseIndex + 5] = ((i+1) * m_pTLoader->nVtxPerCol) + k + 1;

			// next quad
			baseIndex += 6;
		}
	}
	m_pIdxBuff->Unlock();

	return TRUE;
}


//-----------------------------------------------------------------------------//
// ���
//-----------------------------------------------------------------------------//
void CTerrain::Render()
{
	if( !m_bLoaded ) return;

	SetRenderState();

	Matrix44 mat;
	mat.SetIdentity();
	g_pDevice->SetTransform( D3DTS_WORLD, (D3DMATRIX*)&mat );

//	if( m_pTexture ) m_pTexture->SetTexture( 0 );

	g_pDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE );
    g_pDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    g_pDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );

	g_pDevice->SetTexture( 0, m_pTexture );
	g_pDevice->SetFVF( SVertex::FVF );
	g_pDevice->SetStreamSource( 0, m_pVtxBuff, 0, sizeof(SVertex) );


	// Generate TriIndex by QuadTree
	SVertex *pv = NULL;
	m_pVtxBuff->Lock( 0, 0, (void**)&pv, 0 );
	WORD *pi = NULL;
	m_pDynamicIdxBuff->Lock( 0, 0, (void**)&pi, 0 );
	int cnt = 0;
	cnt = m_pQuadTree->GenerateIndex( pi, pv, &g_Frustum, 0.01f );
	m_pDynamicIdxBuff->Unlock();
	m_pVtxBuff->Unlock();
//	g_Dbg.Console( "tricnt: %d\n", cnt );

	g_pDevice->SetIndices( m_pDynamicIdxBuff );
	g_pDevice->DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 0, 0, m_nVtxCount, 0, cnt );
/**/

//	g_pDevice->SetIndices( m_pIdxBuff );
//	g_pDevice->DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 0, 0, m_nVtxCount, 0, m_nTriCount );

	RenderChunk();

/*
	ModelItor itor = m_DynList.begin();
	while( m_DynList.end() != itor )
		(itor++)->pModel->Render();
	itor = m_RigidList.begin();
	while( m_RigidList.end() != itor )
		(itor++)->pModel->Render();
/**/
}


//-----------------------------------------------------------------------------//
// ���ϸ��̼�
//-----------------------------------------------------------------------------//
void CTerrain::Update( int nElapsTick )
{
//	ModelItor itor = m_DynList.begin();
//	while( m_DynList.end() != itor )
//		(itor++)->pModel->Update( nElapsTick );
}


//-----------------------------------------------------------------------------//
// x, y ��ǥ�� ���̸� ��´�.
//-----------------------------------------------------------------------------//
float CTerrain::GetHeight( float x, float y )
{
/*
	x = ((float)m_pTLoader->nWidth / 2.0f) - x;
	y = ((float)m_pTLoader->nHeight / 2.0f) - y;

	x /= (float)m_pTLoader->nCellSize;
	y /= (float)m_pTLoader->nCellSize;

	float col = ::floorf( x );
	float row = ::floorf( y );

    //  A   B
    //  *---*
    //  | / |
    //  *---*
    //  C   D
	float A = GetHeightMapEntry( row, col );
	float B = GetHeightMapEntry( row, col+1 );
	float C = GetHeightMapEntry( row+1, col );
	float D = GetHeightMapEntry( row+1, col+1 );

	float dx = x - col;
	float dy = y - row;

	float height = 0.0f;
	if( dy < 1.0f - dx )  // upper triangle ABC
	{
		float uy = B - A; // A->B
		float vy = C - A; // A->C
		height = A + SD_Util::Lerp(0.0f, uy, dx) + SD_Util::Lerp(0.0f, vy, dy);
	}
	else // lower triangle DCB
	{
		float uy = C - D; // D->C
		float vy = B - D; // D->B
		height = D + SD_Util::Lerp(0.0f, uy, 1.0f - dx) + SD_Util::Lerp(0.0f, vy, 1.0f - dy);
	}

	return height;
/**/
	return 0.f;
}


//-----------------------------------------------------------------------------//
// map height �迭�� row, col ��ġ�ǰ��� �����Ѵ�.
//-----------------------------------------------------------------------------//
float CTerrain::GetHeightMapEntry( int nRow, int nCol )
{
	if( 0 > nRow || 0 > nCol )
		return 0.f;
	if( m_nVtxCount <= (nRow * m_pTLoader->nVtxPerCol + nCol) ) 
		return 0.f;

//	return m_vecHeight[ nRow * m_pTLoader->nVtxPerCol + nCol];
	return m_pTLoader->pMap[ nRow * m_pTLoader->nVtxPerCol + nCol];
}


//-----------------------------------------------------------------------------//
// Screen���� 2d��ǥ pPos���� 3d Map��ǥ�� ���´�.
//-----------------------------------------------------------------------------//
BOOL CTerrain::Pick( Vector2 *pPos, Vector3 *pvTarget )
{
	if( !m_pVtxBuff ) return FALSE;

	Vector3 vOrig, vDir;
	GetPickRay( (int)pPos->x, (int)pPos->y, &vOrig, &vDir );

	*pvTarget = Vector3(0,0,0);
	int nSize = m_nTriCount * 3;

	SVertex *pv = NULL;
	WORD *pi = NULL;
	m_pVtxBuff->Lock( 0, 0, (void**)&pv, 0 );
	m_pIdxBuff->Lock( 0, 0, (void**)&pi, 0 );
	for( int i=0; i < nSize; i+=3 )
	{
		Vector3 v1 = pv[ pi[ i+0]].vP;
		Vector3 v2 = pv[ pi[ i+1]].vP;
		Vector3 v3 = pv[ pi[ i+2]].vP;

		Triangle tri( v1, v2, v3 );
		Plane p( v1, v2, v3 );

		float a = vDir.DotProduct( p.N );
		if( a >= 0 ) continue;

		float t;
		if( tri.Intersect(vOrig, vDir, &t ) )
		{
			if( 0 == pvTarget->x && 0 == pvTarget->y && 0 == pvTarget->z )
			{
				*pvTarget = vOrig + vDir * t;
			}
			else
			{
				Vector3 v = vOrig + vDir * t;
				if( vOrig.LengthRoughly(v) < vOrig.LengthRoughly(*pvTarget) )
					*pvTarget = v;
			}
		}
	}

	m_pVtxBuff->Unlock();
	m_pIdxBuff->Unlock();

	if( 0 == pvTarget->x && 0 == pvTarget->y && 0 == pvTarget->z )
		return FALSE;

	return TRUE;
}


//-----------------------------------------------------------------------------//
// map texture�� light���� �����Ѵ�.
//-----------------------------------------------------------------------------//
void CTerrain::CalcLight( Vector3 *pvLightDir )
{
//	if( !m_pTexture ) return;
/*
	int nWidth = m_pTLoader->nCellPerCol;
	int nHeight = m_pTLoader->nCellPerRow;

	DWORD *pImage;
	m_pTexture->Lock( (BYTE**)&pImage );
	int nPitch = (nWidth + 3) & (~3);
	for( int i=0; i < nHeight; ++i )
	{
		for( int k=0; k < nWidth; ++k )
		{
			D3DXCOLOR c = pImage[i * nPitch + k];
			c *= CalcShade( i, k, pvLightDir );
			c.a = 255;
			pImage[i * nPitch + k] = (D3DCOLOR)c;
		}
	}
	m_pTexture->Unlock();
/**/
}


//-----------------------------------------------------------------------------//
// row, col��ġ���� �������͸� ������ pvLightDir���� �������� �����Ѵ�.
// returnvlaue = 0~1
//-----------------------------------------------------------------------------//
float CTerrain::CalcShade( int nCellRow, int nCellCol, Vector3 *pvLightDir )
{
	float fHeightA = GetHeightMapEntry( nCellRow, nCellCol );
	float fHeightB = GetHeightMapEntry( nCellRow, nCellCol+1 );
	float fHeightC = GetHeightMapEntry( nCellRow+1, nCellCol );

	Vector3 u( (float)m_pTLoader->nCellSize, 0.0f, fHeightB - fHeightA );
	Vector3 v( 0, (float)-m_pTLoader->nCellSize, fHeightC - fHeightA );

	Vector3 n;
	n = v.CrossProduct( u );
 	n.Normalize();

	pvLightDir->Normalize();

	float fCosine = n.DotProduct( *pvLightDir );
	if( fCosine < .0f )
		fCosine = .0f;

	return fCosine;
}


//-----------------------------------------------------------------------------//
// renderstate
//-----------------------------------------------------------------------------//
void CTerrain::SetRenderState()
{
    g_pDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );
	g_pDevice->SetRenderState( D3DRS_FILLMODE, (D3DPT_LINELIST==m_nRenderType)? D3DFILL_WIREFRAME : D3DFILL_SOLID );
	g_pDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
	g_pDevice->SetRenderState( D3DRS_FOGENABLE, m_bFog );


/*
	// enable specular lighting
	g_pDevice->SetRenderState(D3DRS_SPECULARENABLE, FALSE );
	
	g_pDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,	1		);
	g_pDevice->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA	);
	g_pDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );
	g_pDevice->SetRenderState( D3DRS_ALPHATESTENABLE,	1		);

	g_pDevice->SetRenderState( D3DRS_ALPHAREF,	0x05 );
	g_pDevice->SetRenderState( D3DRS_ALPHAFUNC,	D3DCMP_GREATEREQUAL );
/*
	// Sampler State
		static float fBias = 0.2F;
		SET_SAMPLER_STATE( 0, D3DSAMP_MIPMAPLODBIAS, *((LPDWORD) (&fBias)) );
		SET_SAMPLER_STATE( 1, D3DSAMP_MIPMAPLODBIAS, *((LPDWORD) (&fBias)) );
	// ~Sampler State

	// Texture ���� ����
	SET_STAGE_STATE( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	SET_STAGE_STATE( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	SET_STAGE_STATE( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );

	SET_STAGE_STATE( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	SET_STAGE_STATE( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	SET_STAGE_STATE( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );

	// TFactor
	SET_STAGE_STATE( 1, D3DTSS_COLOROP,   D3DTOP_DISABLE );

	SET_STAGE_STATE( 1, D3DTSS_ALPHAOP,   D3DTOP_DISABLE );
/**/
	g_pDevice->SetRenderState( D3DRS_ZENABLE, D3DZB_TRUE );
	g_pDevice->SetRenderState( D3DRS_ZWRITEENABLE, TRUE );
/**/
}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
BOOL CTerrain::AddTModel( Vector2 vPos, OBJ_TYPE eOType, char *szObjName, CModel *pAdd )
{
/*
	STModel tmodel;
	tmodel.vPos = vPos;

	SD_CModel *pModel = CopyModel( eOType, pAdd );
	if( !pModel )
		return FALSE;

	tmodel.nId = ++m_nTModelId;
	strcpy( tmodel.szObjName, szObjName );
	tmodel.pModel = pModel;
	Vector3 p( vPos.x, vPos.y, GetHeight(vPos.x, vPos.y) ); // ���̰� ����
	tmodel.pModel->SetPos( &p );

	if( OT_MODEL == eOType )
		m_DynList.push_back( tmodel );
	else if( OT_RIGID == eOType )
		m_RigidList.push_back( tmodel );
/**/
	return TRUE;
}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
BOOL CTerrain::DelTModel( OBJ_TYPE eOType, int nId )
{
/*
	if( OT_MODEL == eOType )
	{
		ModelItor itor = m_DynList.begin();
		while( m_DynList.end() != itor )
		{
			if( nId == (itor)->nId )
			{
				delete itor->pModel;
				m_DynList.erase( itor );
				break;				
			}
			++itor;
		}
	}

	if( OT_RIGID == eOType )
	{
		ModelItor itor = m_RigidList.begin();
		while( m_RigidList.end() != itor )
		{
			if( nId == (itor)->nId )
			{
				delete itor->pModel;
				m_RigidList.erase( itor );
				break;				
			}
			++itor;
		}
	}
/**/
	return TRUE;
}

/*
//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
SD_CModel* CTerrain::CopyModel( OBJ_TYPE eOType, SD_CModel *pModel )
{
	SD_CModel *p = NULL;
	if( eOType == OT_MODEL )
	{
		p = new SD_CDynModel;
		*(SD_CDynModel*)p = *(SD_CDynModel*)pModel;
	}
	else if( eOType == OT_RIGID )
	{
		p = new SD_CRigidModel;
		*(SD_CRigidModel*)p = *(SD_CRigidModel*)pModel;
	}
	else
	{
		return NULL;
	}

	return p;
}

/**/


//-----------------------------------------------------------------------------//
// ��ũ����ǥ x,y�� proj, view����� ���� view���� ��ǥ��, pick�� ��ǥ�� ��´�.
//-----------------------------------------------------------------------------//
void CTerrain::GetPickRay( int nX, int nY, Vector3* pvOrig, Vector3* pvDir )
{
	float	x =  ( (nX * 2.0F / g_Camera.m_Viewport.Width  ) - 1.0F );
	float	y = -( (nY * 2.0F / g_Camera.m_Viewport.Height ) - 1.0F );

	Vector3		v;
	v.x = ( x - g_Camera.m_matProj._31 ) / g_Camera.m_matProj._11;
	v.y = ( y - g_Camera.m_matProj._32 ) / g_Camera.m_matProj._22;
	v.z =  1.0F;

	Matrix44&	m = g_Camera.m_matView.Inverse();

	pvDir->x = v.x * m._11 + v.y * m._21 + v.z * m._31;
	pvDir->y = v.x * m._12 + v.y * m._22 + v.z * m._32;
	pvDir->z = v.x * m._13 + v.y * m._23 + v.z * m._33;

	pvOrig->x = m._41;
	pvOrig->y = m._42;
	pvOrig->z = m._43;
}


//-----------------------------------------------------------------------------//
// ûũ �ʱ�ȭ
//-----------------------------------------------------------------------------//
void CTerrain::InitChunk()
{
	for( int cy=0; cy < CHUNK_ROW; ++cy )
	{
		for( int cx=0; cx < CHUNK_COL; ++cx )
		{
			const int chunk_width = m_ColumnCellCountPerChunk * m_Cell_Size;
			const int chunk_height = m_RowCellCountPerChunk * m_Cell_Size;

			const int startx = ((chunk_width * cx) - (CHUNK_COL*chunk_width)/2);
			const int starty = ((CHUNK_ROW*chunk_height)/2) - (chunk_height * cy);
			const int endx = startx + chunk_width;
			const int endy = starty - chunk_height;

			m_Chunk[ cx][ cy].Init(startx, starty, chunk_width, chunk_height, m_Cell_Size, 5);

		}
	}
}


//-----------------------------------------------------------------------------//
// ûũ ���
//-----------------------------------------------------------------------------//
void CTerrain::RenderChunk()
{
	g_pDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
	g_pDevice->SetRenderState( D3DRS_SRCBLEND, D3DBLEND_SRCALPHA );
	g_pDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );

	g_pDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, 0 );
	g_pDevice->SetTextureStageState( 1, D3DTSS_TEXCOORDINDEX, 0 );

	for( int y=0; y < CHUNK_ROW; ++y )
	{
		for( int x=0; x < CHUNK_COL; ++x )
		{
			CChunk *pchunk = &m_Chunk[ x][ y];
			if( !pchunk->m_Visible ) continue;

			const int vtxsize = (pchunk->m_columnCellCount+1) * (pchunk->m_rowCellCount+1);
			const int trisize = (pchunk->m_columnCellCount) * (pchunk->m_rowCellCount) * 2;
			for( int i=0; i < pchunk->m_layerCount; ++i )
			{
				if( !(CChunk::VISIBLE & pchunk->layer[ i].flag) ) 
					continue;

				g_pDevice->SetTexture( 0, pchunk->layer[ i].palpha );
				g_pDevice->SetTexture( 1, pchunk->layer[ i].ptexture );

				g_pDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
				g_pDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
				g_pDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
				g_pDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );

				g_pDevice->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
				g_pDevice->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_TEXTURE );
				g_pDevice->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_CURRENT );
				g_pDevice->SetTextureStageState( 1, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
				g_pDevice->SetTextureStageState( 1, D3DTSS_ALPHAARG1, D3DTA_CURRENT );

				g_pDevice->SetStreamSource( 0, pchunk->m_pvtxBuff, 0, sizeof(SVertex) );
				g_pDevice->SetFVF( SVertex::FVF );
				g_pDevice->SetIndices( pchunk->m_pidxBuff );
				g_pDevice->DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 0, 0, vtxsize, 0, trisize );
			}
		}
	}

	g_pDevice->SetTexture( 0, NULL );
	g_pDevice->SetTexture( 1, NULL );
	g_pDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, 0 );
	g_pDevice->SetTextureStageState( 1, D3DTSS_TEXCOORDINDEX, 1 );
	g_pDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE );
}


//-----------------------------------------------------------------------------//
// ûũ ����
//-----------------------------------------------------------------------------//
void CTerrain::ClearChunk()
{
	for( int y=0; y < CHUNK_ROW; ++y )
	{
		for( int x=0; x < CHUNK_COL; ++x )
		{
			m_Chunk[ x][ y].m_Visible = FALSE;
			m_Chunk[ x][ y].m_x = x;
			m_Chunk[ x][ y].m_y = y;
			m_Chunk[ x][ y].m_columnCellCount = m_ColumnCellCountPerChunk;
			m_Chunk[ x][ y].m_rowCellCount = m_RowCellCountPerChunk;
			m_Chunk[ x][ y].m_cellSize = (float)m_Cell_Size;

			SAFE_RELEASE( m_Chunk[ x][ y].m_pidxBuff );
			SAFE_RELEASE( m_Chunk[ x][ y].m_pvtxBuff );
			SAFE_RELEASE( m_Chunk[ x][ y].m_pvtxBuff_Edge );

			for( int i=0; i < m_Chunk[ x][ y].m_layerCount; ++i )
			{
				SAFE_RELEASE( m_Chunk[ x][ y].layer[ i].palpha );
				SAFE_ADELETE( m_Chunk[ x][ y].layer[ i].palphaname );
				SAFE_ADELETE( m_Chunk[ x][ y].layer[ i].ptexturename );
			}
		}
	}
}

