//-----------------------------------------------------------------------------//
// 2009-08-11  programer: jaejung ��(���բ�)��
// 
//-----------------------------------------------------------------------------//

#if !defined(__UTILITY_H__)
#define __UTILITY_H__

#include <list>


BOOL CollectFile( std::list<std::string> *pFindExt, char *szDirectory, std::list<std::string> *pFileList );

void NormalizeRect( RECT *prt );

#endif // __UTILITY_H__
