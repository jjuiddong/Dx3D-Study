#if !defined(AFX_TESTDLG3_H__AB1E81EA_10F4_4775_9F6A_8840CCDF0E44__INCLUDED_)
#define AFX_TESTDLG3_H__AB1E81EA_10F4_4775_9F6A_8840CCDF0E44__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TestDlg3.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTestDlg3 dialog

class CTestDlg3 : public CDialog
{
// Construction
public:
	CTestDlg3(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTestDlg3)
	enum { IDD = IDD_DIALOG1 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestDlg3)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTestDlg3)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTDLG3_H__AB1E81EA_10F4_4775_9F6A_8840CCDF0E44__INCLUDED_)
