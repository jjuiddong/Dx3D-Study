// TerrainPanel.cpp : implementation file
//

#include "stdafx.h"
#include "MapTool2.h"
#include "TerrainPannel.h"
#include "mapview.h"
#include "global.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTerrainPanel dialog


CTerrainPanel::CTerrainPanel(CWnd* pParent /*=NULL*/)
	: CDialog(CTerrainPanel::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTerrainPanel)
	m_nHOffset = 0;
	m_EditTerrain = FALSE;
	m_strHOffset = _T("");
	m_strBrushSize = _T("");
	m_nBrushSize = 0;
	m_strCursorPos = _T("");
	m_bUpDown = TRUE;
	//}}AFX_DATA_INIT
}


void CTerrainPanel::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTerrainPanel)
	DDX_Slider(pDX, IDC_SLIDER_HOFFSET, m_nHOffset);
	DDX_Check(pDX, IDC_CHECK_EDIT, m_EditTerrain);
	DDX_Text(pDX, IDC_EDIT_HOFFSET, m_strHOffset);
	DDX_Text(pDX, IDC_EDIT_BRUSHSIZE, m_strBrushSize);
	DDX_Slider(pDX, IDC_SLIDER_BRUSHSIZE, m_nBrushSize);
	DDX_Text(pDX, IDC_STATIC_CURSORPOS, m_strCursorPos);
	DDX_Check(pDX, IDC_CHECK_UPDOWN, m_bUpDown);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTerrainPanel, CDialog)
	//{{AFX_MSG_MAP(CTerrainPanel)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_HOFFSET, OnReleasedcaptureSliderHoffset)
	ON_BN_CLICKED(IDC_CHECK_EDIT, OnCheckEdit)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_BRUSHSIZE, OnReleasedcaptureSliderBrushsize)
	ON_WM_SHOWWINDOW()
	ON_BN_CLICKED(IDC_CHECK_UPDOWN, OnCheckUpdown)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTerrainPanel message handlers

BOOL CTerrainPanel::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_nHOffset = 66;
	m_nBrushSize = 50;
	m_strHOffset = "3.0";
	m_strBrushSize = "20.0";

	g_pTerrainView->SetHeightOffset( 3.f );
	g_pTerrainView->SetBrushSize( 20.f );

	UpdateData( FALSE );

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
void CTerrainPanel::OnReleasedcaptureSliderHoffset(NMHDR* pNMHDR, LRESULT* pResult)
{
	UpdateData();

	float fOffset = ((float)m_nHOffset * 0.03f) + 1.f;
	g_pTerrainView->SetHeightOffset( fOffset );

	m_strHOffset.Format( "%.1f", fOffset );
	UpdateData( FALSE );

	*pResult = 0;
}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
void CTerrainPanel::OnCheckEdit() 
{
	UpdateData();
	g_pTerrainView->ChangedEditMode( (m_EditTerrain)? EM_TERRAIN : EM_NORMAL );
}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
void CTerrainPanel::OnReleasedcaptureSliderBrushsize(NMHDR* pNMHDR, LRESULT* pResult) 
{
	UpdateData();

	float fSize = ((float)m_nBrushSize*0.2f) + 10.f;
	g_pTerrainView->SetBrushSize( fSize );
	m_strBrushSize.Format( "%.1f", fSize );
	UpdateData( FALSE );

	*pResult = 0;
}


void CTerrainPanel::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	if( bShow ) 
	{
//		g_eEditMode = EM_TERRAIN;	
//		g_pTerrainView->ChangedEditMode( g_eEditMode );
//		m_EditTerrain = FALSE;
//		UpdateData( FALSE );
	}
}


//-----------------------------------------------------------------------------//
// Cursor���� Update
//-----------------------------------------------------------------------------//
void CTerrainPanel::UpdateCursorInfo( const Vector3 &pos )
{
	m_strCursorPos.Format( "{ %.1f, %.1f, %.1f }", pos.x, pos.y, pos.z );
	UpdateData( FALSE );
}


void CTerrainPanel::OnCheckUpdown() 
{
	UpdateData();
	g_pTerrainView->SetEditTerrainMode( m_bUpDown );
}
