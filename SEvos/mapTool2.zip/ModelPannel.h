#if !defined(AFX_MODELPANEL_H__0557E951_EF5F_4963_9BBD_63BFF0EFA6E1__INCLUDED_)
#define AFX_MODELPANEL_H__0557E951_EF5F_4963_9BBD_63BFF0EFA6E1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ModelPanel.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CModelPanel dialog
#include "filetree.h"

class CModelPanel : public CDialog
{
// Construction
public:
	CModelPanel(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CModelPanel)
	enum { IDD = IDD_DLG_MODEL };
	CFileTree m_FileTree;
	//}}AFX_DATA

protected:
	void LoadTable();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CModelPanel)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CModelPanel)
	afx_msg void OnButtonReflesh();
	virtual BOOL OnInitDialog();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MODELPANEL_H__0557E951_EF5F_4963_9BBD_63BFF0EFA6E1__INCLUDED_)
