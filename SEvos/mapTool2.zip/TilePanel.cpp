// TilePanel.cpp : implementation file
//

#include "stdafx.h"
#include "maptool2.h"
#include "TilePanel.h"

#include "global.h"
#include "utility.h"
#include "mapview.h"

#include "terraineditor.h"


//#include <gdiplus.h>
//#pragma comment(lib, "gdiplus")
//using namespace Gdiplus;

using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTilePanel dialog


CTilePanel::CTilePanel(CWnd* pParent /*=NULL*/)
	: CDialog(CTilePanel::IDD, pParent), 
	m_pCurrentChunk(NULL),
	m_bDrag(FALSE)
{
	//{{AFX_DATA_INIT(CTilePanel)
	m_strBrushCenter = _T("");
	m_strBrushSize = _T("");
	m_strBrushSpeed = _T("");
	m_strChunkPos = _T("");
	m_strMaxLayerCount = _T("");
	m_strTileDirPath = _T("");
	m_chkEditTileMode = FALSE;
	m_strCenterAlpha = _T("");
	m_strEdgeAlpha = _T("");
	m_chkErase = FALSE;
	m_chkMatchTexture = FALSE;
	//}}AFX_DATA_INIT
}


void CTilePanel::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTilePanel)
	DDX_Control(pDX, IDC_LIST_LAYER, m_LayerList);
	DDX_Control(pDX, IDC_SLIDER_BRUSHSPEED, m_BrushSpeed);
	DDX_Control(pDX, IDC_SLIDER_BRUSHSIZE, m_BrushSize);
	DDX_Control(pDX, IDC_SLIDER_BRUSHCENTER, m_BrushCenter);
	DDX_Control(pDX, IDC_LIST_TILE, m_TileList);
	DDX_Text(pDX, IDC_STATIC_BRUSHCENTER, m_strBrushCenter);
	DDX_Text(pDX, IDC_STATIC_BRUSHSIZE, m_strBrushSize);
	DDX_Text(pDX, IDC_STATIC_BRUSHSPEED, m_strBrushSpeed);
	DDX_Text(pDX, IDC_STATIC_CHUNKPOS, m_strChunkPos);
	DDX_Text(pDX, IDC_STATIC_MAXLAYERCOUNT, m_strMaxLayerCount);
	DDX_Text(pDX, IDC_STATIC_TILE_DIRPATH, m_strTileDirPath);
	DDX_Check(pDX, IDC_CHECK_TILEEDIT, m_chkEditTileMode);
	DDX_Text(pDX, IDC_EDIT_CENTER_ALPHA, m_strCenterAlpha);
	DDX_Text(pDX, IDC_EDIT_EDGE_ALPHA, m_strEdgeAlpha);
	DDX_Check(pDX, IDC_CHECK_ERASEBRUSH, m_chkErase);
	DDX_Check(pDX, IDC_CHECK_MATCH_TEXTURE, m_chkMatchTexture);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTilePanel, CDialog)
	//{{AFX_MSG_MAP(CTilePanel)
	ON_BN_CLICKED(IDC_BUTTON_REFRESH, OnButtonRefresh)
	ON_BN_CLICKED(IDC_BUTTON_DELETELAYER, OnButtonDeletelayer)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_BRUSHCENTER, OnReleasedcaptureSliderBrushcenter)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_BRUSHSIZE, OnReleasedcaptureSliderBrushsize)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_BRUSHSPEED, OnReleasedcaptureSliderBrushspeed)
	ON_LBN_SELCHANGE(IDC_LIST_TILE, OnSelchangeListTile)
	ON_BN_CLICKED(IDC_CHECK_TILEEDIT, OnCheckTileedit)
	ON_EN_CHANGE(IDC_EDIT_CENTER_ALPHA, OnChangeEditCenterAlpha)
	ON_EN_CHANGE(IDC_EDIT_EDGE_ALPHA, OnChangeEditEdgeAlpha)
	ON_BN_CLICKED(IDC_BUTTON_SHOWLAYER, OnButtonShowlayer)
	ON_BN_CLICKED(IDC_BUTTON_EDITLAYER, OnButtonEditlayer)
	ON_BN_CLICKED(IDC_BUTTON_HIDELAYER, OnButtonHidelayer)
	ON_BN_CLICKED(IDC_BUTTON_LOCKLAYER, OnButtonLocklayer)
	ON_BN_CLICKED(IDC_CHECK_ERASEBRUSH, OnCheckErasebrush)
	ON_BN_CLICKED(IDC_CHECK_MATCH_TEXTURE, OnCheckMatchTexture)
	ON_WM_MOUSEWHEEL()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTilePanel message handlers

void CTilePanel::OnButtonRefresh() 
{
	RefreshTileList( (char*)g_szTilePath );
}

BOOL CTilePanel::OnInitDialog() 
{
	CDialog::OnInitDialog();
	GetClientRect( m_PannelViewPort );
	
	m_strTileDirPath = CString("Directory: ") + g_szTilePath;
	RefreshTileList( (char*)g_szTilePath );

	// Slider
	m_BrushCenter.SetRange( 1, 100 );
	m_BrushSize.SetRange( 1, 100 );
	m_BrushSpeed.SetRange( 1, 100 );

	m_BrushInfo.load = FALSE;
	m_BrushInfo.flag = 0;
	m_BrushInfo.radius = .8f;
	m_BrushInfo.center_radius = .4f;
	m_BrushInfo.offset = 10.f;
	m_BrushInfo.edge_alpha = 0.f;
	m_BrushInfo.center_alpha = 1.f;
	m_BrushInfo.texture[ 0] = NULL;

	m_BrushCenter.SetPos( (int)(m_BrushInfo.center_radius * 100.f) );
	m_BrushSize.SetPos( (int)(m_BrushInfo.radius * 100.f) );
	m_BrushSpeed.SetPos( (int)m_BrushInfo.offset );
	
	m_strBrushCenter.Format( "%d", m_BrushCenter.GetPos() );
	m_strBrushSize.Format( "%d", m_BrushSize.GetPos() );
	m_strBrushSpeed.Format( "%d", m_BrushSpeed.GetPos() );

	m_strCenterAlpha.Format( "%1.1f", m_BrushInfo.center_alpha );
	m_strEdgeAlpha.Format( "%1.1f", m_BrushInfo.edge_alpha );

	m_chkErase = m_BrushInfo.flag & SBrushInfo::ERASE;
	m_chkMatchTexture = m_BrushInfo.flag & SBrushInfo::MATCH;

	m_strMaxLayerCount.Format( "max layer count: %d", CTerrain::MAX_LAYER_CNT );
	m_strChunkPos.Format( "chunk pos: {x, y}" );

	m_LayerList.SetExtendedStyle( LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES );

	UpdateData( FALSE );

	return TRUE;
}


//-----------------------------------------------------------------------------//
// Ÿ�����ϸ���Ʈ�� ������Ʈ �Ѵ�.
//-----------------------------------------------------------------------------//
void CTilePanel::RefreshTileList( char *szDirectory )
{
	list<string> extlist, filelist;
	extlist.push_back( "bmp" );
	extlist.push_back( "tga" );
	extlist.push_back( "jpg" );
	extlist.push_back( "tng" );

	CollectFile( &extlist, szDirectory, &filelist );

	while( LB_ERR != m_TileList.DeleteString(0) ) {} // List Clear

	list<string>::iterator it = filelist.begin();
	while( filelist.end() != it )
		m_TileList.AddString( it++->c_str() );
}

void CTilePanel::OnReleasedcaptureSliderBrushcenter(NMHDR* pNMHDR, LRESULT* pResult) 
{
	UpdateData();
	m_BrushInfo.center_radius = (float)m_BrushCenter.GetPos() / 100.f;
	m_strBrushCenter.Format( "%d", m_BrushCenter.GetPos() );
	UpdateData( FALSE );

//	float fSize = ((float)m_nBrushSize*0.2f) + 10.f;
//	g_pMapView->SetBrushSize( fSize );
//	m_strBrushSize.Format( "%.1f", fSize );
//	UpdateData( FALSE );

	*pResult = 0;
}

void CTilePanel::OnReleasedcaptureSliderBrushsize(NMHDR* pNMHDR, LRESULT* pResult) 
{
	UpdateData();
	m_BrushInfo.radius = (float)m_BrushSize.GetPos() / 100.f;
	m_strBrushSize.Format( "%d", m_BrushSize.GetPos() );
	UpdateData( FALSE );
	
	*pResult = 0;
}

void CTilePanel::OnReleasedcaptureSliderBrushspeed(NMHDR* pNMHDR, LRESULT* pResult) 
{
	UpdateData();
	m_BrushInfo.offset = (float)m_BrushSpeed.GetPos();
	m_strBrushSpeed.Format( "%d", m_BrushSpeed.GetPos() );
	UpdateData( FALSE );
	
	*pResult = 0;
}

void CTilePanel::OnSelchangeListTile() 
{
	CString filename;
	m_TileList.GetText( m_TileList.GetCurSel(), filename );
	strcpy_s( m_BrushInfo.texture, sizeof(m_BrushInfo.texture), (LPCTSTR)filename );
	m_BrushInfo.load = TRUE;

}

void CTilePanel::OnCheckTileedit() 
{
	UpdateData();
	g_pTerrainView->ChangedEditMode( (m_chkEditTileMode)? EM_TILE : EM_NORMAL );	
}

void CTilePanel::OnChangeEditCenterAlpha() 
{
	UpdateData();
	float alpha = (float)atof( m_strCenterAlpha );
	if( 0.f > alpha ) alpha = 0.f;
	if( 1.f < alpha ) alpha = 1.f;
	m_BrushInfo.center_alpha = alpha;
}

void CTilePanel::OnChangeEditEdgeAlpha() 
{
	UpdateData();
	float alpha = (float)atof( m_strEdgeAlpha );
	if( 0.f > alpha ) alpha = 0.f;
	if( 1.f < alpha ) alpha = 1.f;
	m_BrushInfo.edge_alpha = alpha;	
}


//-----------------------------------------------------------------------------//
// �ʿ��� ���õ� ûũ�� Ÿ���гο� ����Ѵ�.
//-----------------------------------------------------------------------------//
void CTilePanel::SetCurrentChunk( CChunk *pchunk )
{
//	if( !pchunk ) return;
//	if( !m_pCurrentChunk )
//		m_pCurrentChunk = pchunk;
//	else if( (m_pCurrentChunk->x == pchunk->x) && (m_pCurrentChunk->y == pchunk->y) )
//		return;

	m_pCurrentChunk = pchunk;
	m_LayerList.SetCurrentChunk( pchunk );
	if( pchunk )
		m_strChunkPos.Format( "chunk pos: {%d, %d}", pchunk->m_x, pchunk->m_y );
	else
		m_strChunkPos.Format( "chunk pos: {x, y}" );
	m_LayerList.DeleteAllItems();

	if( pchunk )
		for( int i=0; i < pchunk->m_layerCount; ++i )
			m_LayerList.InsertItem( i, MakeLayerListString(i, &pchunk->layer[ i]) );

	UpdateData( FALSE );
}

void CTilePanel::OnButtonDeletelayer() 
{
	if( !m_pCurrentChunk ) return;
	CTerrainEditor *pterrain = g_pTerrainView->GetTerrain();

	POSITION pos = m_LayerList.GetFirstSelectedItemPosition();
	if( !pos ) return;
	int ndelcnt = 0;
	while( pos )
	{
		int nItem = m_LayerList.GetNextSelectedItem( pos );
		pterrain->DeleteLayer( m_pCurrentChunk, nItem - ndelcnt++ );
	}

	// Update Layer List
	SetCurrentChunk( m_pCurrentChunk );
}

void CTilePanel::OnButtonShowlayer() 
{
	if( !m_pCurrentChunk ) return;
	SetLayerFlag( m_pCurrentChunk, CChunk::VISIBLE, TRUE );
}

void CTilePanel::OnButtonEditlayer() 
{
	if( !m_pCurrentChunk ) return;
	SetLayerFlag( m_pCurrentChunk, CChunk::EDIT, TRUE );	
}

void CTilePanel::OnButtonHidelayer() 
{
	if( !m_pCurrentChunk ) return;
	SetLayerFlag( m_pCurrentChunk, CChunk::VISIBLE, FALSE );
}

void CTilePanel::OnButtonLocklayer() 
{
	if( !m_pCurrentChunk ) return;
	SetLayerFlag( m_pCurrentChunk, CChunk::EDIT, FALSE );	
}

//-----------------------------------------------------------------------------//
// LayerList�� ��µ� ���̾� ���� ��Ʈ���� �����.
//-----------------------------------------------------------------------------//
CString CTilePanel::MakeLayerListString( int layeridx, CChunk::SLayer *player )
{
	CString num;
	num.Format( "[%d]", layeridx );
	CString flag( "<" );
	if( CChunk::VISIBLE & player->flag ) flag += 'V';
	if( CChunk::EDIT & player->flag ) flag += " E";
	flag += '>';

	return num + flag + " " + player->ptexturename;
}


//-----------------------------------------------------------------------------//
// ���̾��Ʈ�� ���õ� ���̾���� �ϰ������� �÷��װ��� �����Ѵ�.
// pchunk: ���̾ ����� ûũ
// flag: ������ �÷��� ����
// onoff: �÷��׸� On��Ű���� TRUE, Off��Ű���� FALSE
//-----------------------------------------------------------------------------//
void CTilePanel::SetLayerFlag( CChunk *pchunk, DWORD flag, BOOL onoff )
{
	if( !pchunk ) return;

	POSITION pos = m_LayerList.GetFirstSelectedItemPosition();
	if( !pos ) return;

	while( pos )
	{
		int nItem = m_LayerList.GetNextSelectedItem( pos );
		pchunk->layer[ nItem].flag = 
			(onoff)? m_pCurrentChunk->layer[ nItem].flag | flag : (m_pCurrentChunk->layer[ nItem].flag & ~flag);
		m_LayerList.SetItemText( nItem, 0, MakeLayerListString(nItem, &m_pCurrentChunk->layer[ nItem]) );
	}
}

void CTilePanel::OnCheckErasebrush() 
{
	UpdateData();
	m_BrushInfo.flag = 
		(m_chkErase)? (m_BrushInfo.flag | SBrushInfo::ERASE) : (m_BrushInfo.flag & ~SBrushInfo::ERASE);
}

void CTilePanel::OnCheckMatchTexture() 
{
	UpdateData();
	m_BrushInfo.flag = 
		(m_chkMatchTexture)? (m_BrushInfo.flag | SBrushInfo::MATCH) : (m_BrushInfo.flag & ~SBrushInfo::MATCH);
}

BOOL CTilePanel::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	m_PannelViewPort.OffsetRect( 0, (0<zDelta)? 20 : -20 );
	m_PannelViewPort.left = 0;
	if( 0 < m_PannelViewPort.top ) m_PannelViewPort.top = 0;
	MoveWindow( m_PannelViewPort );

	return CDialog::OnMouseWheel(nFlags, zDelta, pt);
}

void CTilePanel::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// WM_MOUSEWHEEL �޼����� �ޱ����ؼ� �ٸ� ��Ʈ�ѿ� ��Ŀ���� �����.
	CWnd *pwnd = GetDlgItem( IDC_STATIC_CHUNKPOS );
	pwnd->SetFocus();
	m_bDrag = TRUE;
	GetCursorPos( &m_ptClickPos );
	SetCapture();
	CDialog::OnLButtonDown(nFlags, point);
}

void CTilePanel::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if( m_bDrag ) ReleaseCapture();
	m_bDrag = FALSE;
	CDialog::OnLButtonUp(nFlags, point);
}

void CTilePanel::OnMouseMove(UINT nFlags, CPoint point) 
{
	if( m_bDrag )
	{
		CPoint pos;
		GetCursorPos( &pos );
		CPoint offset = pos - m_ptClickPos;
		offset.x = 0;
		m_PannelViewPort.OffsetRect( offset );
		m_PannelViewPort.left = 0;
		if( 0 < m_PannelViewPort.top ) m_PannelViewPort.top = 0;
		MoveWindow( m_PannelViewPort );

		m_ptClickPos = pos;
	}	
	
	CDialog::OnMouseMove(nFlags, point);
}
