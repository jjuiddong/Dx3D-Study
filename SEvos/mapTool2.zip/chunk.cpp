
#include "StdAfx.h"

#include "Global.h"
#include "terrain.h"
#include "chunk.h"


//------------------------------------------------------------------------
// 
// [2011/2/9 jjuiddong]
//------------------------------------------------------------------------
void CChunk::Init(int chunkPosX, int chunkPosY, int chunkWidth, int chunkHeight, int cellSize, int layerCount)
{
	m_columnCellCount = chunkWidth / cellSize;
	m_rowCellCount = chunkHeight / cellSize;
	m_columnVtxCount = m_columnCellCount + 1;
	m_rowVtxCount = m_rowCellCount + 1;
	m_cellSize = (float)cellSize;

	const int chunk_vtxsize = (m_columnVtxCount) * (m_rowVtxCount);
	const int chunk_trisize = (m_columnCellCount * m_rowCellCount) * 2;

	m_Visible = TRUE;
	m_Flag = CChunk::VISIBLE;
	m_x = chunkPosX;
	m_y = chunkPosY;
	m_layerCount = 0;
	m_pvtxBuff = NULL;
	m_pidxBuff = NULL;

	const int startx = chunkPosX;
	const int starty = chunkPosY;
	const int endx = startx + chunkWidth;
	const int endy = starty - chunkHeight;

	const float uCoordIncrementSize = 1.0f / (float)m_columnCellCount;
	const float vCoordIncrementSize = 1.0f / (float)m_rowCellCount;

	// create chunk edge
	g_pDevice->CreateVertexBuffer( 5*sizeof(SVtxDiff), 0, SVtxDiff::FVF, 
		D3DPOOL_MANAGED, &m_pvtxBuff_Edge, NULL );

	// create vertex buffer
	g_pDevice->CreateVertexBuffer( chunk_vtxsize*sizeof(CTerrain::SVertex), 0, CTerrain::SVertex::FVF, 
		D3DPOOL_MANAGED, &m_pvtxBuff, NULL );
	CTerrain::SVertex *pv = NULL;
	m_pvtxBuff->Lock( 0, 0, (void**)&pv, 0 );
	int i=0;
	for( int y=starty; y >= endy; y -= cellSize, ++i )
	{
		int k=0;
		for( int x=startx; x <= endx; x += cellSize, ++k )
		{
			int index = (i * m_columnVtxCount) + k;
			pv[ index] = CTerrain::SVertex( (float)x, 0.1f, (float)y, 
				((float)k*uCoordIncrementSize), (float)i*vCoordIncrementSize );
		}
	}

	m_pvtxBuff->Unlock();

	// create index buffer
	g_pDevice->CreateIndexBuffer( chunk_trisize*3*sizeof(WORD), D3DUSAGE_WRITEONLY, 
		D3DFMT_INDEX16, D3DPOOL_MANAGED, &m_pidxBuff, NULL );
	WORD *pi = NULL;
	m_pidxBuff->Lock( 0, 0, (void**)&pi, 0 );

	int baseIndex = 0;
	for( i=0; i < m_rowCellCount; ++i )
	{
		for( int k=0; k < m_columnCellCount; ++k )
		{
			pi[ baseIndex]     = (  i   * m_columnVtxCount) + k;
			pi[ baseIndex + 1] = (  i   * m_columnVtxCount) + k + 1;
			pi[ baseIndex + 2] = ((i+1) * m_columnVtxCount) + k;

			pi[ baseIndex + 3] = ((i+1) * m_columnVtxCount) + k;
			pi[ baseIndex + 4] = (  i   * m_columnVtxCount) + k + 1;
			pi[ baseIndex + 5] = ((i+1) * m_columnVtxCount) + k + 1;

			// next quad
			baseIndex += 6;
		}
	}
	m_pidxBuff->Unlock();

	UpdateChunkEdge();

	// Init Layer
	for( int m=0; m < layerCount; ++m )
	{
		layer[ m].flag = 0;
		layer[ m].palpha = NULL;
		layer[ m].ptexture = NULL;
		layer[ m].ptexturename = NULL;
	}
}


//-----------------------------------------------------------------------------//
// ûũ�� �ܰ����� ûũ �������� �°� �ٽ� ������Ʈ �Ѵ�.
// pchunk: ������Ʈ�� ûũ
//-----------------------------------------------------------------------------//
void CChunk::UpdateChunkEdge()
{
	const int chunk_vtxsize = m_columnVtxCount * m_rowVtxCount;

	SVtxDiff *pvd = NULL;
	m_pvtxBuff_Edge->Lock( 0, 0, (void**)&pvd, 0 );

	CTerrain::SVertex *pv = NULL;
	m_pvtxBuff->Lock( 0, 0, (void**)&pv, 0 );

	// init chunk edge
	// ûũ�� 4���� �ܰ� �������� �����Ѵ�.
	DWORD color = D3DXCOLOR( 1.f, 0, 1.f, 0 );
	pvd[ 0].v = pv[0].vP;
	pvd[ 0].c = color;
	pvd[ 1].v = pv[ m_columnVtxCount-1].vP;
	pvd[ 1].c = color;
	pvd[ 2].v = pv[ chunk_vtxsize-1].vP;
	pvd[ 2].c = color;
	pvd[ 3].v = pv[ chunk_vtxsize-m_columnVtxCount].vP;
	pvd[ 3].c = color;
	pvd[ 4].v = pv[0].vP;
	pvd[ 4].c = color;

	for( int q=0; q < 5; ++q )
		pvd[ q].v.y += 0.1f;

	m_pvtxBuff->Unlock();
	m_pvtxBuff_Edge->Unlock();
}

