// MapView.cpp : implementation file
//

#include "stdafx.h"
#include "MapTool2.h"
#include "MapView.h"
#include "global.h"
//#include "terraineditor.h"
#include "terrainpannel.h"
#include "terraineditor.h"
#include "tilepanel.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// Cross Line ���
inline void DrawXYZ()
{
	g_pDevice->SetRenderState( D3DRS_LIGHTING, FALSE );

	g_pDevice->SetTransform( D3DTS_WORLD, &g_matIdentity ); // identity matrix

	const int cross_size = 6;
	SVtxDiff crossline[ cross_size];
	// x axis
	crossline[ 0].v = Vector3( 0.f, 0.f, 0.f );
	crossline[ 1].v = Vector3( 100.f, 0.f, 0.f );
	crossline[ 0].c = D3DXCOLOR( 1, 0, 0, 0 );
	crossline[ 1].c = D3DXCOLOR( 1, 0, 0, 0 );
	// y axis
	crossline[ 2].v = Vector3( 0.f, 0.f, 0.f );
	crossline[ 3].v = Vector3( 0.f, 100.f, 0.f );
	crossline[ 2].c = D3DXCOLOR( 0, 1, 0, 0 );
	crossline[ 3].c = D3DXCOLOR( 0, 1, 0, 0 );
	// z axis
	crossline[ 4].v = Vector3( 0.f, 0.f, 0.f );
	crossline[ 5].v = Vector3( 0.f, 0.f, 100.f );
	crossline[ 4].c = D3DXCOLOR( 0, 0, 1, 0 );
	crossline[ 5].c = D3DXCOLOR( 0, 0, 1, 0 );
	g_pDevice->SetFVF( SVtxDiff::FVF );
	g_pDevice->DrawPrimitiveUP( D3DPT_LINELIST, cross_size/2, crossline, sizeof(SVtxDiff) );


	SVtxDiff tri[ 9];
	tri[ 0].v = Vector3( 0.f, 0.f, 0.f );
	tri[ 0].c = D3DXCOLOR( 1, 0, 0, 0 );
	tri[ 2].v = Vector3( 10.f, 0.f, 0.f );
	tri[ 2].c = D3DXCOLOR( 0, 1, 0, 0 );
	tri[ 1].v = Vector3( 5.f, 5.f, 0.f );
	tri[ 1].c = D3DXCOLOR( 0, 0, 1, 0 );

	tri[ 3].v = Vector3( 0.f, 0.f, 0.f );
	tri[ 3].c = D3DXCOLOR( 1, 0, 0, 0 );
	tri[ 5].v = Vector3( -5.f, 5.f, 0.f );
	tri[ 5].c = D3DXCOLOR( 0, 0, 1, 0 );
	tri[ 4].v = Vector3( -10.f, 0.f, 0.f );
	tri[ 4].c = D3DXCOLOR( 0, 1, 0, 0 );

	tri[ 6].v = Vector3( 0.f, 0.f, 0.f );
	tri[ 6].c = D3DXCOLOR( 1, 0, 0, 0 );
	tri[ 8].v = Vector3( 5.f, 5.f, 0.f );
	tri[ 8].c = D3DXCOLOR( 0, 1, 0, 0 );
	tri[ 7].v = Vector3( -5.f, 5.f, 0.f );
	tri[ 7].c = D3DXCOLOR( 0, 0, 1, 0 );
	g_pDevice->SetFVF( SVtxDiff::FVF );
	g_pDevice->DrawPrimitiveUP( D3DPT_TRIANGLELIST, 3, tri, sizeof(SVtxDiff) );


	g_pDevice->SetRenderState( D3DRS_LIGHTING, TRUE );
}

void CALLBACK TimerProc( UINT uTimerID, DWORD dwParam )
{
	CMapView *pView = (CMapView*)dwParam;
	pView->TimerEvent( uTimerID );
}


/////////////////////////////////////////////////////////////////////////////
// CMapView
CMapView::CMapView():
	m_pTerrain(NULL), 
//	m_pCamera(NULL), 
	m_vLight(0,0,1), m_bDrag(FALSE), m_bBrush(FALSE), 
	m_eEditOrder(TERRAIN_UP),
	m_bHover(FALSE), m_bAlt( FALSE ),
	m_pDxFont(NULL), m_pTextSprite(NULL),
	m_EditMode( EM_NORMAL )
{
	m_fRMouseZ = 20.f;
	m_fBrushSize = 20.f;
	m_fHeightOffset = 1;
	m_ElapseTime = 0;
	m_Fps = 0;

	sprintf_s( m_szFps, sizeof(m_szFps), "fps: 0" );
}

CMapView::~CMapView()
{
	SAFE_DELETE( m_pTerrain );
	SAFE_RELEASE( m_pTextSprite );
	SAFE_RELEASE( m_pDxFont );


//	SAFE_DELETE( m_pCamera );
}


BEGIN_MESSAGE_MAP(CMapView, CView)
	//{{AFX_MSG_MAP(CMapView)
	ON_WM_ERASEBKGND()
	ON_WM_MOUSEWHEEL()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONUP()
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMapView drawing

void CMapView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

BOOL CMapView::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}

BOOL CMapView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	if( 0 == nFlags )
		m_Mouse.SetMouseWheel( -zDelta );
	return CView::OnMouseWheel(nFlags, zDelta, pt);
}

void CMapView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	SetFocus();

	switch( m_EditMode )
	{
	case EM_NORMAL:
		{
			m_ptClickPos = point;
			m_bDrag = TRUE;
	//		m_Box.Box( m_ptClickPos.x, m_ptClickPos.y, m_ptClickPos.x, m_ptClickPos.y, 0xff000000, 0.1f );

			CChunk *pchunk = m_pTerrain->GetChunkFrom2D( Vector2((float)point.x, (float)point.y) );
			g_pTilePanel->SetCurrentChunk( pchunk );
			m_pTerrain->SetFocusChunk( pchunk );
		}
		break;

	case EM_TILE:
		{
			m_bBrush = TRUE;
			if( !m_pTerrain->DrawBrush(g_pTilePanel->GetBrushInfo(), Vector2((float)point.x, (float)point.y)) )
				m_bBrush = FALSE;
		}
		break;

	case EM_TERRAIN:
		{
			m_bBrush = TRUE;
			Vector3 vTarget;
			if( m_pTerrain->Pick( &Vector2((float)point.x,(float)point.y), &vTarget ) )
			{
				m_vEditPos = Vector2( vTarget.x, vTarget.z );
				SetCapture();
			}
		}
		break;

	case EM_MODEL:
		{
			Vector3 vTarget;
			if( m_pTerrain->Pick( &Vector2((float)point.x, (float)point.y), &vTarget ) )
			{
//				m_pTerrain->LocateModel( Vector2(vTarget.x,vTarget.y) );
			}
		}
		break;
	}

	CView::OnLButtonDown(nFlags, point);
}

void CMapView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	SetFocus();	

	switch( m_EditMode )
	{
	case EM_MODEL:
		HoverCancel();
		break;
	}

	CView::OnRButtonDown(nFlags, point);
}

void CMapView::OnRButtonUp(UINT nFlags, CPoint point) 
{
	if( m_bBrush )
	{
		m_Timer.KillTimer( TERRAIN_DOWN );
		m_bBrush = FALSE;
	}

	ReleaseCapture();
	CView::OnRButtonUp(nFlags, point);
}


void CMapView::OnMouseMove(UINT nFlags, CPoint point) 
{
	SetFocus();

	switch( m_EditMode )
	{
	case EM_NORMAL:
		if( m_bDrag )
		{
	//		m_Box.Box( m_ptClickPos.x, m_ptClickPos.y, point.x, point.y, 0xff000000, 0.1f );
		}
		break;

	case EM_TILE:
		{
			Vector3 vTarget;
			m_pTerrain->Pick(&Vector2((float)point.x, (float)point.y), &vTarget);
			m_vEditPos = Vector2(vTarget.x, vTarget.z);
			m_pTerrain->MoveBrush( g_pTilePanel->GetBrushInfo(), m_vEditPos );

			if (m_bBrush) {
				m_pTerrain->DrawBrush( g_pTilePanel->GetBrushInfo(), Vector2((float)point.x, (float)point.y) );
			}
		}
		break;

	case EM_TERRAIN:
		if( m_bBrush )
		{
			Vector3 vTarget;
			if( m_pTerrain->Pick( &Vector2((float)point.x, (float)point.y), &vTarget ) )
			{
				m_vEditPos = Vector2( vTarget.x, vTarget.z );
			}
			else
			{
				m_bBrush = FALSE;
			}
		}
		break;

	case EM_MODEL:
		if( m_bHover )
		{
			Vector3 vTarget;
			if( m_pTerrain->Pick( &Vector2((float)point.x, (float)point.y), &vTarget ) )
			{
	//			m_pTerrain->MoveHoverObj( Vector2(vTarget.x, vTarget.y) );
			}
		}
		break;
	}
	
	CView::OnMouseMove(nFlags, point);
}

void CMapView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if( m_bDrag  )
	{
		RECT rcDrag = {m_ptClickPos.x, m_ptClickPos.y, point.x, point.y };
//		SD_Util::SetRectNormalize( &rcDrag );
		// Hover ����?
//		if( 2 == m_pTerrain->Capture( &rcDrag ) ) 
//		{
//			m_bHover = TRUE;
//		}

		m_bDrag = FALSE;
	}

	if( m_bBrush )
	{
		m_bBrush = FALSE;
	}

	ReleaseCapture();
	CView::OnLButtonUp(nFlags, point);
}

/////////////////////////////////////////////////////////////////////////////
// CMapView diagnostics

#ifdef _DEBUG
void CMapView::AssertValid() const
{
	CView::AssertValid();
}

void CMapView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMapView message handlers


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
BOOL CMapView::Init()
{
//	m_pTerrain = new CMapEditor;
	m_Timer.Create( TimerProc, (DWORD)this );

//	RECT r;
	m_Mouse.Init( m_hWnd );
//	_SD_CScreen::GetViewPort( &r );
	CRect r;
	GetClientRect( r );
	m_Mouse.SetViewport( 0, 0, r.Width(), r.Height() );

	m_Mouse.Update();
	m_nRMouseX = m_Mouse.GetMouseX();
	m_nRMouseY = m_Mouse.GetMouseY();

//	m_Box.Box( 10, 10, 100, 100, 0xff000000 );

	// create sprite
	HRESULT hr;
    if( FAILED(hr = D3DXCreateSprite(g_pDevice, &m_pTextSprite)) )
        return FALSE;
	// create text
	hr = D3DXCreateFont( g_pDevice, 18, 0, FW_BOLD, 1, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
						DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "����", &m_pDxFont );
	if( FAILED(hr) )
		return FALSE;

	return TRUE;
}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
BOOL CMapView::FileOpen( char *szFileName )
{
//	SAFE_DELETE( m_pTerrain );

//	m_pTerrain = new CTerrainEditor;
//	if( !m_pTerrain->Load(szFileName) )
//		return FALSE;
//	m_pTerrain->GenerateTexture();
//	m_pTerrain->CalcLight( &Vector3(0,0,1.f) );
//	m_pTerrain->SetFog( 0x0000cccc, 10.0f, 200.f );

	return TRUE;
}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
BOOL CMapView::FileSave( char *szFileName )
{
//	return m_pTerrain->Save( szFileName );
	return FALSE;
}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
BOOL CMapView::CreateTerrain( SCrTerrain *pCrTerrain )
{
	SAFE_DELETE( m_pTerrain );

	m_pTerrain = new CTerrainEditor;
	m_pTerrain->Load( "aa", pCrTerrain->nVtxPerRow, pCrTerrain->nVtxPerCol, 10, 1.f );
//	m_pTerrain->Create( pCrTerrain );
//	m_pTerrain->GenerateTexture();
//	m_pTerrain->CalcLight( &Vector3(0,0,1.f) );
//	m_pTerrain->SetFog( 0x0000cccc, 10.0f, 200.f );

	return TRUE;
}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
void CMapView::Render()
{
	RenderFps();

	DrawXYZ();

	MouseProc();

//	g_D3D.ShowFrameRate();
	
	if( m_pTerrain )
		m_pTerrain->Render();

	if( m_bDrag )
	{
//		m_Box.SetRenderState();
//		m_Box.Render();
	}
/**/

}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
void CMapView::Update( int nElapsTick )
{
	m_pTerrain->Update( nElapsTick );

	CPoint curpos;
	GetCursorPos( &curpos );
	CRect cr;
	GetClientRect( cr );
	ClientToScreen( cr );
	if( !cr.PtInRect(curpos) )
		return;

	KeyProc( nElapsTick );

	switch( m_EditMode )
	{
	case EM_TERRAIN:
		if( m_bBrush )
		{
			float val = m_fHeightOffset * ((float)nElapsTick * 0.01f);
			m_pTerrain->SetHeight( m_vEditPos, CT_CIRCLE, m_fBrushSize, (m_eEditOrder==TERRAIN_UP)? val : -val );
	//		m_pTerrain->GenerateTexture();
	//		m_pTerrain->CalcLight( &m_vLight );
	//		m_pTerrain->UpdateObjPos();
		}
		break;
	}

	// cursor���� ���
	Vector3 vcursor( m_vEditPos.x, 0.f, m_vEditPos.y );
	if( !m_bBrush )
		m_pTerrain->Pick( &Vector2((float)m_nRMouseX, (float)m_nRMouseY), &vcursor );
	g_pTerrainPanel->UpdateCursorInfo( Vector3(vcursor.x,0.f,vcursor.z) );

	// fps ��� ---------------------------------------
	++m_Fps;
	m_ElapseTime += nElapsTick;
	if( 1000 <= m_ElapseTime )
	{
		sprintf_s( m_szFps, sizeof(m_szFps), "fps: %d", m_Fps );
		m_Fps = 0;
		m_ElapseTime = 0;
	}
	//--------------------------------------------------

}


//-----------------------------------------------------------------------------//
// HoverObject ������
//-----------------------------------------------------------------------------//
void CMapView::SelectObj( OBJ_TYPE eOType, char *szObjName )
{
	if( m_bHover )
	{
		if( m_strObjName == szObjName )
			return;
	}

	m_bHover = TRUE;
	m_strObjName = szObjName;
//	m_pTerrain->HoverCancel();
//	m_pTerrain->SetHover( eOType, szObjName );
}


//-----------------------------------------------------------------------------//
// 
// 
// 
//-----------------------------------------------------------------------------//
void CMapView::SetHeight( float fHeight )
{

}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
void CMapView::SetHeightOffset( float fHeightOffset )
{
	m_fHeightOffset = (int)fHeightOffset;
}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
void CMapView::MouseProc()
{
//	if( !m_pTerrain ) return;

	g_Camera.Execute();
	m_Mouse.Update();

	// Push R Button
	if( m_Mouse.GetMouseR() )
	{
		int mx = m_Mouse.GetMouseX() - m_nRMouseX;
		int my = m_Mouse.GetMouseY() - m_nRMouseY;
		g_Camera.RotateY( (float)mx * 0.2f );
		g_Camera.RotateX( (float)my * 0.2f );

//		g_Dbg.Console( "x,y: %d %d\n", mx, my );
	} //if

	if( ::GetAsyncKeyState(VK_CONTROL) & 0x8000f )
	{
		int mx = m_Mouse.GetMouseX() - m_nRMouseX;
		int my = m_Mouse.GetMouseY() - m_nRMouseY;

		m_vLight.RotateZ( mx * 0.2F );
		m_vLight.RotateX( my * 0.2F );
//		m_pTerrain->GenerateTexture();
//		m_pTerrain->CalcLight( &m_vLight );
	}

//	Vector3 vCamPos = g_Camera.GetPosition();
//	vCamPos.z = m_pTerrain->GetHeight(vCamPos.x, vCamPos.y) + m_fRMouseZ;
//	vCamPos.z = m_fRMouseZ;
//	g_Camera.SetPosition( vCamPos );

	m_nRMouseX = m_Mouse.GetMouseX();
	m_nRMouseY = m_Mouse.GetMouseY();

	if( m_Mouse.GetMouseZ() )
	{
		m_fRMouseZ += (float)m_Mouse.GetMouseZ() * 0.08f;
		g_Dbg.Console( "%f\n", m_fRMouseZ );
		if( 0.f > m_fRMouseZ ) 
			m_fRMouseZ = 0.f;
	}
}


//-----------------------------------------------------------------------------//
// key �Է�
//-----------------------------------------------------------------------------//
void CMapView::KeyProc( int nElapsTick )
{
	g_Camera.Execute();
	m_Mouse.Update();

	Vector3 vCamPos = g_Camera.GetPosition();
	vCamPos.y = m_fRMouseZ;
	g_Camera.SetPosition( vCamPos );

	Vector3 vPos = g_Camera.GetPosition();
	Vector3	vDir = g_Camera.GetFront();
	Vector3	vRight = g_Camera.GetRight();

	vDir.y = 0.f;
	vDir.Normalize();
	vRight.y = 0.f;
	vRight.Normalize();

	float fOffset = 10.f * (float)nElapsTick;
	if( ::GetAsyncKeyState( VK_SPACE ) & 0x8000f )
		fOffset *= 0.1f;
	if( ::GetAsyncKeyState('W') & 0x8000f )
		vPos += vDir * fOffset;
	if( ::GetAsyncKeyState('S') & 0x8000f )
		vPos -= vDir * fOffset;
	if( ::GetAsyncKeyState('A') & 0x8000f )
		vPos -= vRight * fOffset;
	if( ::GetAsyncKeyState('D') & 0x8000f )
		vPos += vRight * fOffset;
	if( ::GetAsyncKeyState(VK_MENU) & 0x8000f ) m_bAlt = TRUE;
	else										m_bAlt = FALSE;

	g_Camera.SetPosition( vPos );
}


//-----------------------------------------------------------------------------//
// option id 1 = ��¹�� 
//			value 1 = texture ���(default)
//				  2 = vertex ���
//				  3 = texture + vertex ���
//-----------------------------------------------------------------------------//
BOOL CMapView::SetOption( int nOptId, int nValue )
{
	if( 1 == nOptId )
	{
		// �ϴ� �ӽ� �ڵ�
		int nRT = 0;
//		if( 1 & nValue )	nRT |= D3DPT_LINELIST;
//		if( 2 & nValue )	nRT |= D3DPT_TRIANGLELIST;

		if( 1 == nValue )
			m_pTerrain->SetRenderType( D3DPT_TRIANGLELIST );
		if( 2 == nValue )
			m_pTerrain->SetRenderType( D3DPT_LINELIST );
	}
	else if( 2 == nOptId )
	{
//		m_pTerrain->FogEnable( nValue );
	}

	return TRUE;
}

void CMapView::SetEditTerrainMode( BOOL bUp )
{
	m_eEditOrder = (bUp)? TERRAIN_UP : TERRAIN_DOWN;
}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
void CMapView::TimerEvent( int nTimerId )
{

}


//-----------------------------------------------------------------------------//
// ����Ʈ��� ����
//-----------------------------------------------------------------------------//
void CMapView::ChangedEditMode( EDIT_MODE eMode )
{
	m_EditMode = eMode;

	switch( eMode )
	{
	case EM_NORMAL:
//		m_pTerrain->HoverCancel();
		break;

	case EM_TILE:
		break;

	case EM_MODEL:
		HoverCancel();
		break;

	case EM_TERRAIN:
		HoverCancel();
//		m_pTerrain->HoverCancel();
		break;
	}
}


//-----------------------------------------------------------------------------//
// KeyProc
//-----------------------------------------------------------------------------//
void CMapView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if( VK_ESCAPE == nChar )
	{
		if( m_bHover )
			HoverCancel();
	}

	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}


//-----------------------------------------------------------------------------//
// 
//-----------------------------------------------------------------------------//
void CMapView::HoverCancel()
{
	m_bHover = FALSE;
//	m_pTerrain->HoverCancel();
	m_strObjName.Empty();

}


//-----------------------------------------------------------------------------//
// fps ���
//-----------------------------------------------------------------------------//
void CMapView::RenderFps()
{
	m_pTextSprite->Begin( D3DXSPRITE_ALPHABLEND | D3DXSPRITE_SORT_TEXTURE );

	CRect rc(10,10,200,200);
    m_pDxFont->DrawText( m_pTextSprite, m_szFps, -1, &rc,
                        DT_NOCLIP, D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f ) );

	m_pTextSprite->End();
}
