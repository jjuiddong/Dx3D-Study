
#ifndef __ANIFILELISTBOX_H__
#define __ANIFILELISTBOX_H__

#include "ModelViewer.h"
#include "FileListBox.h"


class CAniFileListBox : public CFileListBox
{
public:
	CAniFileListBox();
	virtual ~CAniFileListBox();

protected:

public:

	virtual BOOL OnInitDialog();
};

#endif
