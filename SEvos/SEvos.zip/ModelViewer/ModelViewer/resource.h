//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ModelViewer.rc
//
#define IDD_EDIT_PANEL                  101
#define IDD_MODELVIEWER_DIALOG          102
#define IDD_VIEW_PANEL                  105
#define IDR_MAINFRAME                   128
#define IDD_FILELIST                    129
#define IDC_BUTTON1                     1006
#define IDC_BUTTON2                     1007
#define IDC_BUTTON3                     1008
#define IDC_FILELIST                    1008
#define IDC_BUTTON4                     1009
#define IDC_LISTNAME                    1009
#define IDC_REFRESH                     1010
#define IDC_NEWPATH                     1011
#define IDC_MODEL_LISTBOX               1019
#define IDC_MODEL_LISTBOX2              1021
#define IDC_ANI_LISTBOX                 1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
