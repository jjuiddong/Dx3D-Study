
#include "StdAfx.h"
#include "Terrain.h"
#include "terrainCursor.h"
#include "common/light.h"
#include "chunkManager.h"


const int g_alphaTextureSize = 64;

CChunkManager::CChunkManager() : 
m_pChunk(NULL)
, m_pTerrain(NULL)
, m_pLoader(NULL)
, m_ChunkSize(0)
{
	m_matWorld.SetIdentity();

}


CChunkManager::~CChunkManager()
{
	Clear();

}


//-----------------------------------------------------------------------------//
// ûũ �ʱ�ȭ
//-----------------------------------------------------------------------------//
void CChunkManager::Init(CTerrain *pTerrain, int colChunkCount, int rowChunkCount)
{
	Clear();

	if (!pTerrain)
		return;

	m_ObjId = d3d::CreateObjectId();

	m_pTerrain = pTerrain;
	m_ColChunkCount = colChunkCount;
	m_RowChunkCount = rowChunkCount;
	m_ChunkSize = colChunkCount * rowChunkCount;

	m_ColumnCellCountPerChunk = pTerrain->GetColumnCellCount() / colChunkCount;
	m_RowCellCountPerChunk = pTerrain->GetRowCellCount() / rowChunkCount;
	m_ColumnVtxCountPerChunk = m_ColumnCellCountPerChunk + 1;
	m_RowVtxCountPerChunk = m_RowCellCountPerChunk + 1;

	m_pChunk = new CChunk[ colChunkCount * rowChunkCount];

	const int chunk_width = (int)((float)m_ColumnCellCountPerChunk * pTerrain->GetCellSize());
	const int chunk_height = (int)((float)m_RowCellCountPerChunk * pTerrain->GetCellSize());

	for( int cy=0; cy < rowChunkCount; ++cy )
	{
		for( int cx=0; cx < colChunkCount; ++cx )
		{
			const int startx = ((chunk_width * cx) - (colChunkCount*chunk_width)/2);
			const int starty = ((rowChunkCount*chunk_height)/2) - (chunk_height * cy);
			const int endx = startx + chunk_width;
			const int endy = starty - chunk_height;

			const int index = cx + cy * rowChunkCount;
			m_pChunk[ index].Init(cx, cy, startx, starty, chunk_width, chunk_height, 
				pTerrain->GetCellSize(), g_alphaTextureSize );
		}
	}
}


//------------------------------------------------------------------------
// 
// [2011/2/28 jjuiddong]
//------------------------------------------------------------------------
void CChunkManager::Load(CTerrain *pTerrain, SChunkGroupLoader *pLoader)
{
	Init(pTerrain, pLoader->colChunkCount, pLoader->rowChunkCount);

	for (int i=0; i < pLoader->chunkCount; ++i)
	{
		m_pChunk[ i].LoadLayer(&pLoader->pchunk[ i]);
	}
}


//------------------------------------------------------------------------
// 
// [2011/3/14 jjuiddong]
//------------------------------------------------------------------------
void CChunkManager::SetRenderState()
{
	g_pDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	g_pDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	g_pDevice->SetSamplerState(1, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	g_pDevice->SetSamplerState(1, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);

	g_pDevice->SetRenderState( D3DRS_LIGHTING, TRUE );
	g_pDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
	g_pDevice->SetRenderState( D3DRS_SRCBLEND, D3DBLEND_SRCALPHA );
	g_pDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );

	g_pDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, 0 );
	g_pDevice->SetTextureStageState( 1, D3DTSS_TEXCOORDINDEX, 0 );

	g_pDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	g_pDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	g_pDevice->SetSamplerState( 1, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	g_pDevice->SetSamplerState( 1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );

	g_pDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	g_pDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	g_pDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
	g_pDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );

	g_pDevice->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
	g_pDevice->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_CURRENT );
	g_pDevice->SetTextureStageState( 1, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
	g_pDevice->SetTextureStageState( 1, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
}


//------------------------------------------------------------------------
// 
// [2011/2/28 jjuiddong]
//------------------------------------------------------------------------
void CChunkManager::Render()
{
	Matrix44 mat;
	mat.SetIdentity();
	g_pDevice->SetTransform( D3DTS_WORLD, (D3DXMATRIX*)&mat );

	SetRenderState();

	for (int i=0; i < m_ChunkSize; ++i)
		m_pChunk[ i].Render(NULL, 0);

	g_pDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, 0 );
	g_pDevice->SetTextureStageState( 1, D3DTSS_TEXCOORDINDEX, 1 );
	g_pDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE );
	g_pDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
}


//------------------------------------------------------------------------
// [2011/3/15 jjuiddong]
//------------------------------------------------------------------------
void CChunkManager::RenderDepth()
{
	Matrix44 mat;
	mat.SetIdentity();
	g_pDevice->SetTransform( D3DTS_WORLD, (D3DXMATRIX*)&mat );

	for (int i=0; i < m_ChunkSize; ++i)
		m_pChunk[ i].RenderDepth();
}


//------------------------------------------------------------------------
// 
// [2011/2/28 jjuiddong]
//------------------------------------------------------------------------
void CChunkManager::RenderEdge()
{
	for (int i=0; i < m_ChunkSize; ++i)
		m_pChunk[ i].RenderEdge();

	for (int i=0; i < m_ChunkSize; ++i)
	{
		if (m_pChunk[ i].IsFocus())
			m_pChunk[ i].RenderEdge();
	}
}


//------------------------------------------------------------------------
// 
// [2011/2/28 jjuiddong]
//------------------------------------------------------------------------
BOOL CChunkManager::Update( int elapseTime )
{
	return TRUE;
}


//------------------------------------------------------------------------
// 
// [2011/2/28 jjuiddong]
//------------------------------------------------------------------------
void CChunkManager::UpdateEdge()
{
	for (int i=0; i < m_ChunkSize; ++i)
		m_pChunk[ i].UpdateEdge();
}


//------------------------------------------------------------------------
// 
// [2011/2/28 jjuiddong]
//------------------------------------------------------------------------
void CChunkManager::SetHeight( CTerrainCursor *pcursor, int nElapsTick )
{
	for (int i=0; i < m_ChunkSize; ++i)
		m_pChunk[ i].ModifyHeight(pcursor, nElapsTick);
}


//------------------------------------------------------------------------
// 
// [2011/2/28 jjuiddong]
//------------------------------------------------------------------------
void CChunkManager::Clear()
{
	SAFE_ADELETE(m_pChunk);
	DeleteChunkGroupLoader(m_pLoader);

}


//------------------------------------------------------------------------
// 
// [2011/2/28 jjuiddong]
//------------------------------------------------------------------------
CChunk* CChunkManager::GetChunkFromPos( Vector3 pickPos, float *pu, float *pv ) // pu = NULL, pv = NULL
{
	// ��� ûũ�� Ŭ���Ǿ����� ã�´�. x,z������ ã��������
	const float chunk_width = m_pChunk[0].GetRegionWidth();
	const float chunk_height = m_pChunk[0].GetRegionHeight();
	const float width = m_pTerrain->GetRegionWidth();
	const float height = m_pTerrain->GetRegionHeight();

	int cx_idx = (int)((pickPos.x + (width / 2.f)) / chunk_width);
	int cy_idx = (int)((pickPos.z + (height / 2.f)) / chunk_height);

	//-----------------------------------------------------------------
	// ���� ������ ���� ���κа� ���� �Ʒ��κ��� Ŭ���Ǿ����� ���õǴ� 
	// ������ �ذ���
	if( m_ColChunkCount == cx_idx )
	{
		if( 0.1f > fabs((pickPos.x + (width / 2.f)) - width) )
			cx_idx -= 1;
	}
	if( m_RowChunkCount == cy_idx )
	{
		if( 0.1f > fabs((pickPos.z + (height / 2.f)) - height) )
			cy_idx -= 1;
	}
	//-----------------------------------------------------------------

	if( (0 > cx_idx) || (m_ColChunkCount < cx_idx) ) return NULL;
	if( (0 > cy_idx) || (m_RowChunkCount < cy_idx) ) return NULL;

	// ������ ���� 0,0�� ��Ÿ���� ������ �ε�������� �ѹ��� ���־�� �Ѵ�.
	cy_idx = m_RowChunkCount - cy_idx - 1;

	// �ؽ��� uv��ǥ�� ��´�.
	const float chunk_x = (cx_idx * chunk_width);
	const float chunk_y = ((m_RowChunkCount - cy_idx - 1) * chunk_height);
	const float pick_u = (pickPos.x + (width / 2.f)) - chunk_x;
	const float pick_v = (pickPos.z + (height / 2.f)) - chunk_y;
	if( pu ) 
		*pu = pick_u / chunk_width;
	if( pv )
		*pv = 1.f - (pick_v / chunk_height);

	const int index = cx_idx + (cy_idx * m_RowChunkCount);
	return &m_pChunk[ index];
}


//------------------------------------------------------------------------
// 
// [2011/2/28 jjuiddong]
//------------------------------------------------------------------------
CChunk* CChunkManager::GetChunkFromScreenPos( Vector2 screenPos, float *pu, float *pv ) // pu,pv=NULL
{
	if (!m_pTerrain) return FALSE;

	Vector3 pick;
	if (!m_pTerrain->Pick(&screenPos, &pick))
		return NULL;

	return GetChunkFromPos( pick, pu, pv );
}


//------------------------------------------------------------------------
// 
// [2011/2/28 jjuiddong]
//------------------------------------------------------------------------
void CChunkManager::UpdateChunkToTerrain()
{
	for (int i=0; i < m_ChunkSize; ++i)
		m_pChunk[ i].UpdateChunkToMainTerrain(m_pTerrain);
}


//------------------------------------------------------------------------
// 
// [2011/2/28 jjuiddong]
//------------------------------------------------------------------------
void CChunkManager::UpdateTerrainToChunk()
{
	for (int i=0; i < m_ChunkSize; ++i)
		m_pChunk[ i].UpdateMainTerrainToChunk(m_pTerrain);
}


//------------------------------------------------------------------------
// 
// [2011/2/28 jjuiddong]
//------------------------------------------------------------------------
CChunk* CChunkManager::SetFocus( CTerrainCursor *pcursor )
{
	CChunk *pchunk = GetChunkFromPos( pcursor->GetCursorPos() );
	for (int i=0; i < m_ChunkSize; ++i)
		m_pChunk[ i].SetFocus(FALSE);

	if (!pchunk)
	{
		return NULL;
	}

	pchunk->SetFocus(TRUE);
	return pchunk;
}


//-----------------------------------------------------------------------------//
// ûũ ���� �������� ûũ������ �����Ѵ�.
// x,y: m_Chunk[ x][ y]
//-----------------------------------------------------------------------------//
CChunk* CChunkManager::GetChunkFrom( int x, int y )
{
	if (!m_pChunk) return NULL;
	if ((0 > x) || (x >= m_ColChunkCount)) return NULL;
	if ((0 > y) || (y >= m_RowChunkCount)) return NULL;

	const int index = x + y * m_RowChunkCount;
	return &m_pChunk[ index];
}


//------------------------------------------------------------------------
// 
// [2011/2/28 jjuiddong]
//------------------------------------------------------------------------
BOOL CChunkManager::DrawBrush( CTerrainCursor *pcursor )
{
	// focus flag �ʱ�ȭ
	int i=0;
	for (int i=0; i < m_ChunkSize; ++i)
		m_pChunk[ i].SetFocus(FALSE);

	for (int i=0; i < m_ChunkSize; ++i)
		m_pChunk[ i].DrawBrush(pcursor);

	return TRUE;
}


//------------------------------------------------------------------------
// 
// [2011/2/28 jjuiddong]
//------------------------------------------------------------------------
SChunkGroupLoader* CChunkManager::GetChunkGroupLoader( char *szAlphaTextureWriteLocatePath )
{
	if (!m_pLoader)
	{
		m_pLoader = NewChunkGroupLoader();
	}

	m_pLoader->chunkCount = m_ChunkSize;
	m_pLoader->rowChunkCount = m_RowChunkCount;
	m_pLoader->colChunkCount = m_ColChunkCount;
	m_pLoader->colCellCountPerChunk = m_ColumnCellCountPerChunk;
	m_pLoader->rowCellCountPerChunk = m_RowCellCountPerChunk;
	m_pLoader->alphaTextureSize = g_alphaTextureSize;

	for (int i=0; i < m_ChunkSize; ++i)
	{
		m_pChunk[ i].GetChunkLoader(szAlphaTextureWriteLocatePath, &m_pLoader->pchunk[ i]);
	}

	return m_pLoader;
}


//------------------------------------------------------------------------
// 
// [2011/2/28 jjuiddong]
//------------------------------------------------------------------------
SChunkGroupLoader* CChunkManager::NewChunkGroupLoader()
{
	SChunkGroupLoader *pLoader = new SChunkGroupLoader();
	pLoader->pchunk = new SChunkLoader[ m_ChunkSize];
	for (int i=0; i < m_ChunkSize; ++i)
	{
		pLoader->pchunk[ i].pLayer = new SLayerLoader[ CChunk::MAX_LAYER_CNT];
	}
	return pLoader;
}


//------------------------------------------------------------------------
// 
// [2011/2/28 jjuiddong]
//------------------------------------------------------------------------
void CChunkManager::DeleteChunkGroupLoader( SChunkGroupLoader *pLoader)
{
	if (!pLoader) return;

	for (int i=0; i < m_ChunkSize; ++i)
	{
		SAFE_ADELETE( pLoader->pchunk[ i].pLayer);
	}
	SAFE_ADELETE(pLoader->pchunk);
	SAFE_DELETE(pLoader);
}

