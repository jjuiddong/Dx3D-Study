
#ifndef __MODELFILELISTBOX_H__
#define __MODELFILELISTBOX_H__

#include "MapTool2.h"
#include "FileListBox.h"


class CModelFielListBox : public CFileListBox
{
public:
	CModelFielListBox();
	virtual ~CModelFielListBox();

protected:

public:
	virtual BOOL OnInitDialog();

};

#endif
