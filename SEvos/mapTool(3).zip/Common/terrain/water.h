
#ifndef __WATER_H__
#define __WATER_H__


class CTerrain;
class CWater : public CDispObject
{
public:
	CWater();
	virtual ~CWater();

protected:
	int m_ObjId;
	Matrix44 m_matWorld;
	IDirect3DTexture9 *m_pTex;
	IDirect3DVertexBuffer9 *m_pVtxBuff;
	IDirect3DIndexBuffer9 *m_pIdxBuff;

	LPD3DXEFFECT m_pEffect;
	D3DXHANDLE m_hTechnique;
	LPDIRECT3DVERTEXDECLARATION9 m_pDecl;

public:
	void Init(CTerrain *pTerrain);
	virtual int GetId() { return m_ObjId; }
	virtual void Render();
	virtual void RenderDepth();
	virtual BOOL Update( int elapseTime );
	virtual Matrix44* GetWorldTM();
	virtual void Clear();

};

#endif
