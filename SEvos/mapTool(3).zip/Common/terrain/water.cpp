
#include "StdAfx.h"
#include "model/dispObject.h"
#include "Terrain.h"
#include "water.h"



CWater::CWater() :
m_pTex(NULL) 
, m_pVtxBuff(NULL)
, m_pIdxBuff(NULL)
{
	m_ObjId = d3d::CreateObjectId();
	m_matWorld.SetIdentity();

}


CWater::~CWater()
{

}


//------------------------------------------------------------------------
// 
// [2011/3/22 jjuiddong]
//------------------------------------------------------------------------
void CWater::Init(CTerrain *pTerrain)
{
	// ���̴� ���� �б�
	HRESULT hr;
	LPD3DXBUFFER pErr;
	if (FAILED(hr = D3DXCreateEffectFromFile(g_pDevice, "hlsl_water.fx", NULL, NULL, 
		D3DXSHADER_DEBUG , NULL, &m_pEffect, &pErr))) {
			MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer(), "ERROR", MB_OK);
			DXTRACE_ERR( "CreateEffectFromFile", hr );
			return;
	}

	D3DVERTEXELEMENT9 decl[] =
	{
		{0,  0, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
		{0, 12, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL,	0},
		D3DDECL_END()
	};

	if (FAILED(hr = g_pDevice->CreateVertexDeclaration(decl, &m_pDecl)))
	{
		DXTRACE_ERR ("CreateVertexDeclaration", hr);
		return;
	}

	m_hTechnique = m_pEffect->GetTechniqueByName( "TShader" );

	// ���ؽ� ����, �ε��� ���� ����
	const int vtxsize = 4;
	g_pDevice->CreateVertexBuffer( vtxsize*sizeof(SVtxNorm), 0, SVtxNorm::FVF, 
		D3DPOOL_MANAGED, &m_pVtxBuff, NULL );

	const float depth = -10.f;
	const float width = pTerrain->GetRegionWidth();
	const float height = pTerrain->GetRegionHeight();

	SVtxNorm *pV;
	m_pVtxBuff->Lock(0, 0, (void**)&pV, 0);
	pV[ 0].v = Vector3(-width/2.f, depth, height/2.f);
	pV[ 1].v = Vector3( width/2.f, depth, height/2.f);
	pV[ 2].v = Vector3( width/2.f, depth, -height/2.f);
	pV[ 3].v = Vector3(-width/2.f, depth, -height/2.f);
	m_pVtxBuff->Unlock();

	const int trisize = 2;
	g_pDevice->CreateIndexBuffer( trisize*3*sizeof(WORD), D3DUSAGE_WRITEONLY, 
		D3DFMT_INDEX16, D3DPOOL_MANAGED, &m_pIdxBuff, NULL );

	WORD *pi = NULL;
	m_pIdxBuff->Lock( 0, 0, (void**)&pi, 0 );
	pi[ 0] = 0; pi[ 1] = 1; pi[ 2] = 3;
	pi[ 3] = 1; pi[ 4] = 2; pi[ 5] = 3;
	m_pIdxBuff->Unlock();

}


//------------------------------------------------------------------------
// 
// [2011/3/22 jjuiddong]
//------------------------------------------------------------------------
void CWater::Render()
{
	static const int triangleSize = 2;
	static const int vertexSize = 4;

/*
	m_pEffect->SetTechnique( m_hTechnique );
//	g_pDevice->SetVertexDeclaration( m_pDecl );
	m_pEffect->Begin(NULL, 0);
	m_pEffect->BeginPass(0);

	Matrix44 mWVP;
	g_Camera.GetViewProjMatrix(&mWVP);
	m_pEffect->SetMatrix( "mWVP", (D3DXMATRIX*)&mWVP);

//	g_pDevice->SetTexture( 0, m_pTex );
	g_pDevice->MultiplyTransform( D3DTS_WORLD, (D3DXMATRIX*)&m_matWorld );
	g_pDevice->SetStreamSource( 0, m_pVtxBuff, 0, sizeof(SVtxNorm) );
	g_pDevice->SetFVF( SVtxNorm::FVF );
	g_pDevice->SetIndices( m_pIdxBuff );
	g_pDevice->DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 0, 0, vertexSize, 0, triangleSize );

	m_pEffect->EndPass();
	m_pEffect->End();
/**/

}


//------------------------------------------------------------------------
// 
// [2011/3/22 jjuiddong]
//------------------------------------------------------------------------
void CWater::RenderDepth()
{

}


//------------------------------------------------------------------------
// 
// [2011/3/22 jjuiddong]
//------------------------------------------------------------------------
BOOL CWater::Update( int elapseTime )
{

	return TRUE;
}


//------------------------------------------------------------------------
// 
// [2011/3/22 jjuiddong]
//------------------------------------------------------------------------
Matrix44* CWater::GetWorldTM()
{
	return &m_matWorld;
}


//------------------------------------------------------------------------
// 
// [2011/3/22 jjuiddong]
//------------------------------------------------------------------------
void CWater::Clear()
{
	SAFE_RELEASE(m_pTex);
	SAFE_RELEASE(m_pVtxBuff);
	SAFE_RELEASE(m_pIdxBuff);
	SAFE_RELEASE(m_pEffect);

}

