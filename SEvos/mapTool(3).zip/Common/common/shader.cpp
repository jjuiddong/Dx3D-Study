
#include "StdAfx.h"
#include "shader.h"



CShader::CShader() :
m_pEffect(NULL) 
, m_hTechnique(NULL)
, m_pDecl(NULL)
{

}


CShader::~CShader()
{
	Clear();
}


//------------------------------------------------------------------------
// 
// [2011/3/23 jjuiddong]
//------------------------------------------------------------------------
void CShader::Clear()
{
	SAFE_RELEASE(m_pEffect);
	SAFE_RELEASE(m_pDecl);
}


//------------------------------------------------------------------------
// 
// [2011/3/23 jjuiddong]
//------------------------------------------------------------------------
BOOL CShader::Init(char *szFileName, char *szTechnique)
{
	// ���̴� ���� �б�
	HRESULT hr;
	LPD3DXBUFFER pErr;
	if (FAILED(hr = D3DXCreateEffectFromFile(g_pDevice, szFileName, NULL, NULL, 
		D3DXSHADER_DEBUG , NULL, &m_pEffect, &pErr))) {
			MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer(), "ERROR", MB_OK);
			DXTRACE_ERR( "CreateEffectFromFile", hr );
			return FALSE;
	}

	m_hTechnique = m_pEffect->GetTechniqueByName( "TShader" );

	return TRUE;
}


//------------------------------------------------------------------------
// 
// [2011/3/23 jjuiddong]
//------------------------------------------------------------------------
void CShader::Begin()
{
	m_pEffect->Begin(NULL, 0);
	m_pEffect->SetTechnique( m_hTechnique );
}


//------------------------------------------------------------------------
// 
// [2011/3/23 jjuiddong]
//------------------------------------------------------------------------
void CShader::BeginPass(int pass)
{
	m_pEffect->BeginPass(pass);
}


//------------------------------------------------------------------------
// 
// [2011/3/23 jjuiddong]
//------------------------------------------------------------------------
void CShader::EndPass()
{
	m_pEffect->EndPass();

}


//------------------------------------------------------------------------
// 
// [2011/3/23 jjuiddong]
//------------------------------------------------------------------------
void CShader::End()
{
	m_pEffect->End();

}


//------------------------------------------------------------------------
// 
// [2011/3/23 jjuiddong]
//------------------------------------------------------------------------
void CShader::SetMatrix(char *pKey, const Matrix44 &mat)
{
	m_pEffect->SetMatrix( pKey, (D3DXMATRIX*)&mat );
}
void CShader::SetTexture(char *pKey, IDirect3DTexture9 *pTexture)
{
	m_pEffect->SetTexture( pKey, pTexture );
}
void CShader::CommitChanges()
{
	m_pEffect->CommitChanges();
}
void CShader::SetFloat(char *pKey, float val)
{
	m_pEffect->SetFloat( pKey, val );
}
void CShader::SetVector(char *pKey, const Vector3 &vec )
{
	D3DXVECTOR4 temp(vec.x, vec.y, vec.z, 1.f);
	m_pEffect->SetVector( pKey, &temp );
}
void CShader::SetVector(char *pKey, const D3DXVECTOR4 &vec )
{
	m_pEffect->SetVector( pKey, &vec );
}